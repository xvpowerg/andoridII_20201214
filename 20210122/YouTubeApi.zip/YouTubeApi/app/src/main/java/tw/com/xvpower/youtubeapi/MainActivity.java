package tw.com.xvpower.youtubeapi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailView;

public class MainActivity extends YouTubeBaseActivity {

    private final String id="aP9iEGvKmoc";
    private YouTubePlayerView youTubePlayerView;
    private YouTubeThumbnailView youTubeThumbnailView;
    private YouTubePlayer _youTubePlayer;


    private  class YoutubeInitListener implements YouTubePlayer.OnInitializedListener{

        @Override
        public void onInitializationSuccess(YouTubePlayer.Provider provider,
                                            YouTubePlayer youTubePlayer,
                                            boolean wasRestored) {
            Log.d("Howard","wasRestored:"+wasRestored);
         //wasRestored true 表示無須重讀影片
            if (!wasRestored){
                //載入影片
                youTubePlayer.cueVideo(id);
            }
            //初始化完成
            _youTubePlayer = youTubePlayer;

        }

        @Override
        public void onInitializationFailure(YouTubePlayer.Provider provider,

                                            YouTubeInitializationResult youTubeInitializationResult) {
            Log.e("Howard","Failure:");
           Dialog dialog=
                   youTubeInitializationResult.getErrorDialog(MainActivity.this,0);
            dialog.show();

        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String  apiKey= getString(R.string.youtube_api);
        setContentView(R.layout.activity_main);
        youTubeThumbnailView = findViewById(R.id.youtube_thumbnail);
        youTubeThumbnailView.initialize(apiKey, new YouTubeThumbnailView.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView,
                                                YouTubeThumbnailLoader youTubeThumbnailLoader) {
                //設定縮圖
                youTubeThumbnailLoader.setVideo(id);
            }

            @Override
            public void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult) {
                Log.e("Howard","Thumbnail Error!!");
            }
        });
        youTubePlayerView = findViewById(R.id.youtube_view);
        YoutubeInitListener listener = new YoutubeInitListener();
        youTubePlayerView.initialize(apiKey,listener);
        youTubeThumbnailView.setOnClickListener(v->{
                String msg = "Play";
                if (_youTubePlayer.isPlaying()){
                    _youTubePlayer.pause();
                    msg = "pause";
                }else{
                    _youTubePlayer.play();
                }
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();

        });
    }
}