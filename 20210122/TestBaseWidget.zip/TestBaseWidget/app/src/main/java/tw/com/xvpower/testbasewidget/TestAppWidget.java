package tw.com.xvpower.testbasewidget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.widget.RemoteViews;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;


public class TestAppWidget extends AppWidgetProvider {
        private Handler handler = new Handler();
        private AppWidgetManager manager;
        private RemoteViews remoteViews;
        private ComponentName thisWidget;
//    @Override
//    public void onReceive(Context context, Intent intent) {
//        super.onReceive(context, intent);
//        Log.d("Howard","onReceive");
//    }


    private void  restTime(){
        while(true){
            handler.post(()->{
                updateTime();
            });
            try{
                TimeUnit.SECONDS.sleep(1);
            }catch(Exception ex){

            }

        }
    }
    private void updateTime(){
        LocalTime time = LocalTime.now();
        String timeStr =time.format(DateTimeFormatter.ISO_LOCAL_TIME);
        remoteViews.setTextViewText(R.id.widget_text,timeStr);
        manager.updateAppWidget(thisWidget,remoteViews);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        Log.d("Howard","onUpdate");
        thisWidget = new ComponentName(context,TestAppWidget.class);
        manager = appWidgetManager;
        remoteViews = new
                RemoteViews(context.getPackageName(),R.layout.widget_layout);
         Thread thread = new Thread(this::restTime);
        thread.start();
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        Log.d("Howard","onDeleted");
    }

//    @Override
//    public void onEnabled(Context context) {
//        super.onEnabled(context);
//        Log.d("Howard","onEnabled");
//    }
//
//    @Override
//    public void onDisabled(Context context) {
//        super.onDisabled(context);
//        Log.d("Howard","onDisabled");
//    }
//
//    @Override
//    public void onRestored(Context context, int[] oldWidgetIds, int[] newWidgetIds) {
//        super.onRestored(context, oldWidgetIds, newWidgetIds);
//        Log.d("Howard","onRestored");
//    }
}
