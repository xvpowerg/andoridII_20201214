package tw.com.xvpower.myservice1;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MyService  extends Service {
    private boolean canLoopThread = true;
    private Runnable run = new Runnable() {
        @Override
        public void run() {
            Log.d("Howard",
                    "ThName:"+Thread.currentThread().getName());
            while (canLoopThread){
                Log.d("Howard",new Date().toString());
                try{
                    TimeUnit.SECONDS.sleep(1);
                }catch (Exception ex){

                }
            }

        }
    };
    private Thread th1 = new Thread(run);
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind");
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate!!");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        try{
//            TimeUnit.SECONDS.sleep(10);
//        }catch (Exception ex){
//            Log.d("Howard","Exception:"+ex);
//        }
           if (!th1.isAlive()) th1.start();

        Log.d("Howard","onStartCommand!! 2:"+th1.isAlive());
        return Service.START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy!!");
        canLoopThread = false;
        th1 = null;
    }
}
