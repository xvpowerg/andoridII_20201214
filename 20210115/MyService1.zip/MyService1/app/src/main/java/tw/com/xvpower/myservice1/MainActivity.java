package tw.com.xvpower.myservice1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.startBtn);
        Button stopButton = findViewById(R.id.stopBtn);
        Button toPage2Btn = findViewById(R.id.toPage2Btn);

        btn.setOnClickListener(v->{
            Intent intent = new Intent(this,MyService.class);
            startService(intent);
        });
        stopButton.setOnClickListener(v->{
            Intent intent = new Intent(this,MyService.class);
            stopService(intent);

        });
        toPage2Btn.setOnClickListener(v->{
            Intent activityIntent = new Intent(this,MainActivity2.class);
            startActivity(activityIntent);

        });


    }
}