package tw.com.xvpower.myservice1;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Date;

public class MyServiceHandler extends Service {

 
    private Handler handler = new Handler();
    private Runnable run = new Runnable() {
        @Override
        public void run() {
                Log.d("Howard",
                        "ThName:"+Thread.currentThread().getName());
                Log.d("Howard",new Date().toString());
                handler.postDelayed(this,1000);
        }
    };
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind");
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate!!");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        try{
//            TimeUnit.SECONDS.sleep(10);
//        }catch (Exception ex){
//            Log.d("Howard","Exception:"+ex);
//        }

        Log.d("Howard","onStartCommand!!");

        handler.post(run);
        //Service.START_STICKY 如果Service被Android系統移除了 會自動啟動新的Service 但是 Intent為null
        //Service.START_REDELIVER_INTENT 如果Service被Android系統移除了
           // 會自動啟動新的Service 但是 Intent 內容保留
        //Service.START_NOT_STICKY 如果Service被Android系統移除了 不會啟動新的Service
        return Service.START_REDELIVER_INTENT;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy!!");
        handler.removeCallbacks(run);
    }
}
