package tw.com.xvpower.testcontentprivater;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

import tw.com.xvpower.testcontentprivater.sqlite.DBHelper;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBHelper dbh = new DBHelper(this);
//        dbh.insertData("Ken","12345");
//        dbh.insertData("Lucy","6789");
//        dbh.insertData("Vivin","qwet");
//        dbh.insertData("IRIS","12367");
//        dbh.insertData("Lindy","5523");
          Cursor cursor =  dbh.queryData();
          while(cursor.moveToNext()){
              Log.d("Howard","=======================");
              Log.d("Howard",cursor.getString(0));
              Log.d("Howard",cursor.getString(1));
              Log.d("Howard",cursor.getString(2));
              Log.d("Howard","=======================");
          }
    }
}