package tw.com.xvpower.testcontentprivater.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final String TABLE_NAME = "users";
    private static final String DATABASE_NAME="myApp.db";
    private static final int VERSION = 1;
    private static final String SQL = "CREATE TABLE "+ TABLE_NAME+"(_id INTEGER PRIMARY KEY,"+
            "name TEXT," +
            "pass TEXT)";
    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL);
    }

    public int insertData(String name,String pass){
           SQLiteDatabase db =   getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",name);
        cv.put("pass",pass);

        return (int)db.insert(TABLE_NAME,null,cv);
    }
    public Cursor queryData(){
        SQLiteDatabase db = getReadableDatabase();
        return
                db.rawQuery("SELECT * FROM "+TABLE_NAME,null);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
