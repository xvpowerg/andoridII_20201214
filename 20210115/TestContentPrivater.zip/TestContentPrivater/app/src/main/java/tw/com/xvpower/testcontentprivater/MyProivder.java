package tw.com.xvpower.testcontentprivater;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import tw.com.xvpower.testcontentprivater.sqlite.DBHelper;

public class MyProivder extends ContentProvider {
    DBHelper dbHelper;
    @Override
    public boolean onCreate() {
        dbHelper = new DBHelper(getContext());
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
       // SELECT id,name => String[] projection = {"id","name"};
        // String selection   WHERE "id=? KEN  name=?"
        //  new String[]{"1","Ken"};
        //order by sortOrder
         Cursor cursor =   dbHelper.queryData();
        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        String name= values.getAsString("name");
        String pass = values.getAsString("pass");
        int id = -1;
        try{
          id = dbHelper.insertData(name,pass);
        }catch (Exception ex){
            Log.e("Howard","Exception:"+ex);
        }
        return Uri.parse("content://tw.com.xvpower.MyProivder/users/"+id);
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
