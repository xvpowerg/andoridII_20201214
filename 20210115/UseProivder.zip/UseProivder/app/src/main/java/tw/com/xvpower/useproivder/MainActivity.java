package tw.com.xvpower.useproivder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends AppCompatActivity {
    private Uri myUri = Uri.parse("content://tw.com.xvpower.MyProivder");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Cursor cursor = getContentResolver().
                query(myUri,null,
                        null,null);
       // Log.d("Howard","cursor Count:"+cursor.getCount());
        ListView listView = findViewById(R.id.listView);
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                R.layout.list_item_layout,
                cursor,
                new String[]{"_id","name"},
                new int[]{R.id.idText,R.id.nameText},
                CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        listView.setAdapter(adapter);
        ContentValues cv = new ContentValues();
        cv.put("name","momo");
        cv.put("pass","asdf");

      Uri uri =   getContentResolver().insert(myUri,cv);
      long id = ContentUris.parseId(uri);
      Log.d("Howard","id:"+id);

    }
}