package tw.com.xvpower.bindservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private ServiceConnection serviceConnection;
    private MyBindService.MyBinder  myBinder = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bindBtn = findViewById(R.id.bindBtn);
        Button setBtn = findViewById(R.id.setBtn);
        Button invokeBtn = findViewById(R.id.invokeBtn);
        Button stopBtn =   findViewById(R.id.stopBtn);
        invokeBtn.setEnabled(false);
        stopBtn.setEnabled(false);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Log.d("Howard","onServiceConnected!!:"+service.hashCode());
                myBinder = (MyBindService.MyBinder)service;
                myBinder.msgTextView = findViewById(R.id.countView);
                myBinder.numberEditText = findViewById(R.id.editTextNumber);
                invokeBtn.setEnabled(true);
                stopBtn.setEnabled(true);
            }
        //onServiceDisconnected 不正常移除Service才會呼叫
            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.d("Howard","onServiceDisconnected!!");
            }
        };

        bindBtn.setOnClickListener(v->{
            Intent bindIntent =
                    new Intent(this,MyBindService.class);
            //BIND_AUTO_CREATE 如果Service不存在 幫我建立
            bindService(bindIntent,serviceConnection,BIND_AUTO_CREATE);
        });
        setBtn.setOnClickListener(v->{
            myBinder.showText("Ken!!");
        });
        invokeBtn.setOnClickListener(v-> myBinder.startRandom());
        //如果沒有bind Service 不可直接unbind 不然會出錯
        stopBtn.setOnClickListener(v->{
            stopBtn.setEnabled(false);
            invokeBtn.setEnabled(false);
            unbindService(serviceConnection);});
    }
}