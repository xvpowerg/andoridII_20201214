package tw.com.xvpower.bindservice;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import androidx.annotation.Nullable;

public class MyBindService  extends Service {
    private Handler handler = new Handler();
    MyBinder myBinder= new MyBinder();
    class MyBinder extends Binder {
       public EditText numberEditText;
       public TextView msgTextView;
       public void showText(String msg){
            //顯示文字內容
            setText(msg);
       }
       public void startRandom(){
                //跑亂數
           random();
       }
    }

    private  void setText(String text){
        myBinder.msgTextView.setText(text);
    }


    public void random(){

        String numberStr =
                myBinder.numberEditText.getText().toString();
        int count = Integer.parseInt(numberStr);
        Thread thread = new Thread(()->{

                for (int i =1;i<=count;i++){
                    int random =
                            ThreadLocalRandom.current().nextInt(50000);
                    handler.post(
                            ()-> {
                                Log.d("Howard","handler:"+Thread.currentThread().getName());
                                myBinder.msgTextView.setText(random+"");});
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch (Exception ex){}

                }
        });

        thread.start();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {

        Log.d("Howard","onBind!:");
        return myBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate!");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("Howard","onStartCommand!");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        Log.d("Howard","onDestroy!");
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Howard","onUnbind!");
        return super.onUnbind(intent);
    }
}
