package tw.com.xvpower.testbrodacast1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private MyReceiver1 myReceiver1;
    private BroadcastReceiver myReceiver2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 =  findViewById(R.id.send1Btn);
        Button btn2 =  findViewById(R.id.send2Btn);
        Intent startSerIntent =
                new Intent(this,
                        TestService.class);
        startService(startSerIntent);

        btn2.setOnClickListener(v->{
            Intent action = new Intent(
                    "test.br.service1");
            action.putExtra("msg","Hi Service~");
            sendBroadcast(action);});

        TextView msgText =  findViewById(R.id.msgText);
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String msg = intent.getStringExtra("msg");
                Log.d("Howard","RC2 msg:"+msg);
                msgText.setText(msg);
            }
        };

        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("test.br.rc2");
        registerReceiver(receiver,filter2);

        btn1.setOnClickListener(v->{
            Intent action = new Intent("test.br.rc1");
            sendBroadcast(action);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        myReceiver1 = new MyReceiver1();
        IntentFilter filter = new IntentFilter();
        filter.addAction("test.br.rc1");
        registerReceiver(myReceiver1,filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(myReceiver1);
    }
}