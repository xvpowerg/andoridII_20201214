package tw.com.xvpower.testbrodacast1;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class TestService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        BroadcastReceiver br = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String msg =  intent.getStringExtra("msg");
                test(msg);
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction("test.br.service1");
        registerReceiver(br,filter);
    }

    private void test(String msg){
        Log.d("Howard","Service:"+msg);
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        return super.onStartCommand(intent, flags, startId);
    }
}
