package tw.com.xvpower.testloader2pm25;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.loader.content.AsyncTaskLoader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

import tw.com.xvpower.testloader2pm25.bean.Pm25;
import tw.com.xvpower.testloader2pm25.tools.Tools;

public class JsonLoader extends AsyncTaskLoader<List<Pm25>> {
    public JsonLoader(@NonNull Context context) {
        super(context);
    }


    @Override
    public List<Pm25> loadInBackground() {
        Log.d("Howard","loadInBackground:");
        String json =  Tools.getJson();
        Log.d("Howard","loadInBackground json:"+json);
        List<Pm25> list = new ArrayList<>();
        Gson gson = new GsonBuilder().create();
        Type typeToke = new TypeToken<List<Pm25>>(){}.getType();
        list = gson.fromJson(json,typeToke);
        return list;
    }
}
