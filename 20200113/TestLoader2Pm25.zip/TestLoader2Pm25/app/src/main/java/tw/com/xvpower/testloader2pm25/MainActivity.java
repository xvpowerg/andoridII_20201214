package tw.com.xvpower.testloader2pm25;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.os.Bundle;
import android.util.Log;

import java.util.List;

import okhttp3.OkHttpClient;
import tw.com.xvpower.testloader2pm25.bean.Pm25;
import tw.com.xvpower.testloader2pm25.tools.Tools;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Pm25>> {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LoaderManager loaderManager = LoaderManager.getInstance(this);
        loaderManager.initLoader(1,null,this).forceLoad();
    }

    @NonNull
    @Override
    public Loader<List<Pm25>> onCreateLoader(int id, @Nullable Bundle args) {
            JsonLoader jsonLoader = new JsonLoader(this);
        Log.d("Howard","onCreateLoader:");
        return jsonLoader;
    }

    @Override
    public void onLoadFinished(@NonNull Loader<List<Pm25>> loader, List<Pm25> data) {
        Log.d("Howard","onLoadFinished:"+data);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<List<Pm25>> loader) {

    }
}