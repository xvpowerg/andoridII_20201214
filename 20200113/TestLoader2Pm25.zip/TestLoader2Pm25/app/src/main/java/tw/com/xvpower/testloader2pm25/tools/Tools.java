package tw.com.xvpower.testloader2pm25.tools;

import android.util.Log;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Tools {
    private static String url= "http://opendata.epa.gov.tw/webapi/" +
            "Data/REWIQA/?$orderby=SiteName&$skip=0&$top=1000&format=json";
    public  static String getJson()  {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(url).build();
        try{
            Response response =  client.newCall(request).execute();
            return response.body().string();
        }catch (Exception ex){
            Log.d("Howard","Exception:"+ex);
        }
        return "";
    }
}
