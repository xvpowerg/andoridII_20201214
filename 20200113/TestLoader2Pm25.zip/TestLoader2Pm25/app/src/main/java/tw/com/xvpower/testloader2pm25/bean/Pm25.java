package tw.com.xvpower.testloader2pm25.bean;

import com.google.gson.annotations.SerializedName;

public class Pm25 {
    @SerializedName("SiteName")
    private String siteName;
    @SerializedName("County")
    private String county;
    @SerializedName("Status")
    private String status;
    @SerializedName("PM2.5")
    private String pm25;

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPm25() {
        return pm25;
    }

    public void setPm25(String pm25) {
        this.pm25 = pm25;
    }

    @Override
    public String toString() {
        return "Pm25{" +
                "siteName='" + siteName + '\'' +
                ", county='" + county + '\'' +
                ", status='" + status + '\'' +
                ", pm25='" + pm25 + '\'' +
                '}';
    }
}
