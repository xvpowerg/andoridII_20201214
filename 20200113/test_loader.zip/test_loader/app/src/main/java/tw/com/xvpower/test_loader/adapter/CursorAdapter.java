package tw.com.xvpower.test_loader.adapter;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import tw.com.xvpower.test_loader.R;

public class CursorAdapter extends  RecyclerView.Adapter<CursorAdapter.MyViewHolder> {
        private  Cursor cursor;
    public CursorAdapter( Cursor cursor){
            this.cursor = cursor;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout =
                LayoutInflater.from(parent.getContext()).
                        inflate(R.layout.rc_view_layout,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(layout);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        if (cursor.moveToPosition(position)){
            holder.idText.setText(cursor.getString(0));
            holder.nameText.setText(cursor.getString(1));
        }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView idText;
        private TextView nameText;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            idText = itemView.findViewById(R.id.idTextView);
            nameText = itemView.findViewById(R.id.nameTextView);
        }
    }

}
