package tw.com.xvpower.test_loader;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.loader.content.CursorLoader;

public class MyCursorLoader extends CursorLoader {
    private SQLiteDatabase db;
    public MyCursorLoader(@NonNull Context context, SQLiteDatabase db) {
        super(context);
        this.db = db;
    }

    @Override
    public Cursor loadInBackground() {
        Log.d("Howard","Thread name:"+Thread.currentThread().getName());
        Cursor cursor =db.rawQuery("SELECT _id,title,price FROM coffee_list",null);
        return cursor;
    }
}
