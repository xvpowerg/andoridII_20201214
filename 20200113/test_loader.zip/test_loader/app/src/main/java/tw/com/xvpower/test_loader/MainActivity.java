package tw.com.xvpower.test_loader;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import tw.com.xvpower.test_loader.adapter.CursorAdapter;

public class MainActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<Cursor> {
        private LoaderManager loaderManager;
        private RecyclerView rcView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loaderManager = LoaderManager.getInstance(this);
        loaderManager.initLoader(1,null,this);
        rcView = findViewById(R.id.rcView);

//        final String DB_NAME = "coffee_5000.db";
//        final File filesDir1 = getFilesDir();
//        final File externalFilesDir = getExternalFilesDir("");
//        final String DB_PATH =File.separator+"data"+
//                Environment.getDataDirectory().getAbsolutePath()+
//                File.separator+
//                getApplicationContext().getPackageName()+File.separator+DB_NAME;
//        Log.d("Howard","DB_PATH:"+DB_PATH);
//        Log.d("Howard","filesDir1:"+filesDir1);
//        Log.d("Howard","externalFilesDir:"+externalFilesDir);
    }

    private SQLiteDatabase openDatabase(String dbFile){
        if (new File(dbFile).exists() == false){
            try(InputStream is = getResources().openRawResource(R.raw.coffee_5000);
                FileOutputStream fos = new FileOutputStream(dbFile)){
                byte[] buffer = new byte[1024];
                int count =-1;
                while( (count = is.read(buffer)) > 0){
                    fos.write(buffer,0,count);
                }
            }catch (Exception ex){
                Log.e("Howard","Exception:"+ex);
                return  null;
            }
        }
        //開啟指定資料庫
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(dbFile,null);
        return db;
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        final String DB_NAME = "coffee_5000.db";
        final String DB_PATH =File.separator+"data"+
                Environment.getDataDirectory().getAbsolutePath()+
                File.separator+
                getApplicationContext().getPackageName()+File.separator+DB_NAME;
       // final File externalFilesDir = getExternalFilesDir("data");
     //   final String DB_PATH =externalFilesDir+File.separator+DB_NAME;
        Log.d("Howard",DB_PATH);
        SQLiteDatabase db = openDatabase(DB_PATH);

        MyCursorLoader myCursorLoader = new MyCursorLoader(this,db);
        return myCursorLoader;
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        CursorAdapter ca = new  CursorAdapter(data);
        rcView.setLayoutManager(new LinearLayoutManager(this));
        rcView.setAdapter(ca);
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }
}