package tw.com.xvpower.testjsongson.tools;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.testjsongson.bean.Student;

public class JsonTools {
    public static String getJsonRawData(int rawId, Context context){
        StringBuilder sb = new StringBuilder();
            try(InputStream input = context.getResources().openRawResource(rawId);
                InputStreamReader inR = new InputStreamReader(input);
            ){
                char[] buffer = new char[128];
                int index = -1;
                while ( (index = inR.read(buffer)) != -1){
                    sb.append(buffer,0,index);
                }
            }catch(IOException ex){
                Log.e("Howard","IOException:"+ex);
            }
        return sb.toString();
    }

    public static List<Student> jsonStringToStudentArray(String json){
        List<Student> stList;
        Gson gson = new GsonBuilder().create();
        //TypeToken 可以給泛型
        //特別需要指定List內的類型 就要使用TypeToken
        Type typeToke =
                new TypeToken<ArrayList<Student>>(){}.getType();
        stList = gson.fromJson(json,typeToke);
        //如果使用 gson.fromJson(json,ArrayList.class) 方法
        // 會產生List<LinkedTreeMap> LinkedTreeMap 內包含json的資料
        //key 與value的關係
       // stList = gson.fromJson(json,ArrayList.class);
        return stList;

    }

}
