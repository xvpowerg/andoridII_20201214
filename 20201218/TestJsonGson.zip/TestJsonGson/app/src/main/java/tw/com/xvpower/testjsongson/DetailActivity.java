package tw.com.xvpower.testjsongson;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.testjsongson.application.MyApplication;
import tw.com.xvpower.testjsongson.bean.Exam;
import tw.com.xvpower.testjsongson.bean.Student;

public class DetailActivity  extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);
        MyApplication myapp = (MyApplication)getApplication();
        Student st = myapp.getSelectStudent();
        TextView detailNameTxt = findViewById(R.id.detailNameId);
        ListView examListView =  findViewById(R.id.examList);

        if (st != null){
            detailNameTxt.setText(st.getName());
            Exam[] exams = st.getExam();
            String[] examMsg= new String[exams.length];
            for (int i = 0;i < exams.length;i++){
                examMsg[i] = exams[i].toString();
            }
            ArrayAdapter<String> examAdapter =
                    new ArrayAdapter(this, android.R.layout.simple_list_item_1,
                            android.R.id.text1,examMsg);
            examListView.setAdapter(examAdapter);
            Log.d("Howard","Detail:"+st);
        }

    }
}
