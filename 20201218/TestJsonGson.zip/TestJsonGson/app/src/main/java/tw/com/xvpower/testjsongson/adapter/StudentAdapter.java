package tw.com.xvpower.testjsongson.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import tw.com.xvpower.testjsongson.R;
import tw.com.xvpower.testjsongson.bean.Student;

public class StudentAdapter extends BaseAdapter {
    private List<Student> stList;
    public StudentAdapter(List<Student> list){
        stList = list;
    }
    @Override
    public int getCount() {
        return stList.size();
    }

    @Override
    public Student getItem(int position) {
        return stList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
         View view  = LayoutInflater.from(parent.getContext()).
                 inflate(R.layout.st_list_layout,parent,false);
        TextView nameText =  view.findViewById(R.id.nameId);
        Student st =   getItem(position);
        nameText.setText(st.getName());
        return view;
    }
}
