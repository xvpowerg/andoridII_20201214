package tw.com.xvpower.testjsongson.application;

import android.app.Application;

import tw.com.xvpower.testjsongson.bean.Student;

public class MyApplication  extends Application {
    private Student selectStudent;
    public void setSelectStudent(Student st){
        selectStudent = st;
    }
    public Student getSelectStudent(){
        return selectStudent;
    }

}
