package tw.com.xvpower.testjsongson.bean;

public class Student {
    private String name;
    private Exam[] exam;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Exam[] getExam() {
        return exam;
    }

    public void setExam(Exam[] exam) {
        this.exam = exam;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                '}';
    }
}
