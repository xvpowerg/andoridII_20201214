package tw.com.xvpower.testjsongson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.google.gson.internal.LinkedTreeMap;

import java.util.List;

import tw.com.xvpower.testjsongson.adapter.StudentAdapter;
import tw.com.xvpower.testjsongson.application.MyApplication;
import tw.com.xvpower.testjsongson.bean.Student;
import tw.com.xvpower.testjsongson.tools.JsonTools;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String json = JsonTools.getJsonRawData(R.raw.student,this);
      List<Student> stList =  JsonTools.jsonStringToStudentArray(json);
        MyApplication myApp = (MyApplication)getApplication();

           ListView listView =  findViewById(R.id.stListVIew);
        StudentAdapter sad = new StudentAdapter(stList);
        listView.setAdapter(sad);
        //AdapterView<?> parent, View view, int position, long id
        listView.setOnItemClickListener((p,v,pos,id)->{
             Student st =  stList.get(pos);
             Log.d("Howard","st:"+st);

            Intent startIntent
                    = new Intent(this,DetailActivity.class);
            myApp.setSelectStudent(st);
            startActivity(startIntent);
        });
       // Log.d("Howard","Json:"+json);
       // Log.d("Howard","st:"+st.getName());
    }
}