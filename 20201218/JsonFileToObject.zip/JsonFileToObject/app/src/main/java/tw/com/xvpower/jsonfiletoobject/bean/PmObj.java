package tw.com.xvpower.jsonfiletoobject.bean;

public class PmObj {
    private String siteName;
    private String county;
    private String aqi;

    public PmObj(String siteName, String county, String aqi) {
        this.siteName = siteName;
        this.county = county;
        this.aqi = aqi;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAqi() {
        return aqi;
    }

    public void setAqi(String aqi) {
        this.aqi = aqi;
    }

    @Override
    public String toString() {
        return "PmObj{" +
                "siteName='" + siteName + '\'' +
                ", county='" + county + '\'' +
                ", aqi='" + aqi + '\'' +
                '}';
    }


}
