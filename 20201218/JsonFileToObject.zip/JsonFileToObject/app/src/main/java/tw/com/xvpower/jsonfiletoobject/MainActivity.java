package tw.com.xvpower.jsonfiletoobject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import tw.com.xvpower.jsonfiletoobject.bean.PmObj;

public class MainActivity extends AppCompatActivity {
    String json = "[{\"SiteName\":\"二林\",\"County\":\"彰化縣\",\"AQI\":\"37\",\"Pollutant\":\"\",\"Status\":\"良好\",\"SO2\":\"1\",\"CO\":\"0.25\",\"CO_8hr\":\"0.3\",\"O3\":\"27.6\",\"O3_8hr\":\"29\",\"PM10\":\"24\",\"PM2.5\":\"8\",\"NO2\":\"5\",\"NOx\":\"6.5\",\"NO\":\"1.6\",\"WindSpeed\":\"6.4\",\"WindDirec\":\"25\",\"PublishTime\":\"2020/12/18 18:00:00\",\"PM2.5_AVG\":\"12\",\"PM10_AVG\":\"30\",\"SO2_AVG\":\"2\",\"Longitude\":\"120.409653\",\"Latitude\":\"23.925175\",\"SiteId\":\"35\"},\n" +
            "{\"SiteName\":\"三重\",\"County\":\"新北市\",\"AQI\":\"59\",\"Pollutant\":\"細懸浮微粒\",\"Status\":\"普通\",\"SO2\":\"4.9\",\"CO\":\"3.13\",\"CO_8hr\":\"2.2\",\"O3\":\"-\",\"O3_8hr\":\"-\",\"PM10\":\"23\",\"PM2.5\":\"16\",\"NO2\":\"49\",\"NOx\":\"208.4\",\"NO\":\"159.4\",\"WindSpeed\":\"-\",\"WindDirec\":\"-\",\"PublishTime\":\"2020/12/18 18:00:00\",\"PM2.5_AVG\":\"19\",\"PM10_AVG\":\"29\",\"SO2_AVG\":\"3\",\"Longitude\":\"121.493806\",\"Latitude\":\"25.072611\",\"SiteId\":\"67\"},\n" +
            "{\"SiteName\":\"三義\",\"County\":\"苗栗縣\",\"AQI\":\"26\",\"Pollutant\":\"\",\"Status\":\"良好\",\"SO2\":\"1.9\",\"CO\":\"0.25\",\"CO_8hr\":\"0.2\",\"O3\":\"21.3\",\"O3_8hr\":\"26\",\"PM10\":\"11\",\"PM2.5\":\"3\",\"NO2\":\"11.6\",\"NOx\":\"12.7\",\"NO\":\"1.2\",\"WindSpeed\":\"6\",\"WindDirec\":\"20\",\"PublishTime\":\"2020/12/18 18:00:00\",\"PM2.5_AVG\":\"8\",\"PM10_AVG\":\"12\",\"SO2_AVG\":\"2\",\"Longitude\":\"120.758833\",\"Latitude\":\"24.382942\",\"SiteId\":\"27\"}]";
    private ArrayList<PmObj> pmList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length();i++){
                JSONObject jObj =  jsonArray.getJSONObject(i);
                String siteName = jObj.getString("SiteName");
                String county =  jObj.getString("County");
                String aqi =  jObj.getString("AQI");
                //把JSON資料轉換為物件
                PmObj pmObj = new PmObj(siteName,county,aqi);
                pmList.add(pmObj);
               Log.d("Howard","siteName:"+siteName+
                       " county:"+county+" aqi:"+aqi);


            }
        } catch (JSONException e) {
            Log.e("Howard","JSONException:"+e);
        }


    }
}