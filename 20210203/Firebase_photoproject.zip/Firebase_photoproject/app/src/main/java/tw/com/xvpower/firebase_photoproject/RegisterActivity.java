package tw.com.xvpower.firebase_photoproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    private EditText emailText;
    private  EditText pass1Text;
    private  EditText pass2Text;
    private FirebaseAuth auth;
    private void init(){
        emailText = findViewById(R.id.regAccountEdit);
        pass1Text = findViewById(R.id.regPass1Edit);
        pass2Text = findViewById(R.id.regPass2Edit);
    }

    private void onCompleteListener(Task<AuthResult> task){
        if (task.isSuccessful()){
            Intent toMainPage = new Intent(this,MainActivity.class);
            startActivity(toMainPage);
            Toast.makeText(this,"註冊成功", Toast.LENGTH_SHORT).show();
            finish();
        }else{
            String msg = "註冊失敗"+task.getException().toString();
            Toast.makeText(this,msg, Toast.LENGTH_SHORT).show();
        }


    }
    private void register(View view){
            String email = emailText.getText().toString();
            String pass1 = pass1Text.getText().toString();
            String pass2 = pass2Text.getText().toString();
            if (TextUtils.isEmpty(email)||
                    TextUtils.isEmpty(pass1) ||TextUtils.isEmpty(pass2)){
                Toast.makeText(this,
                        "帳號或密碼不可空白",Toast.LENGTH_SHORT).show();
            }else if(pass1.compareTo(pass2) != 0){
                Toast.makeText(this,
                        "密碼與確認密碼不同",Toast.LENGTH_SHORT).show();
            }else if(pass1.length() < 6){
                Toast.makeText(this,
                        "密碼長度不可小於6",Toast.LENGTH_SHORT).show();
            }else{
                auth.createUserWithEmailAndPassword(email,pass1).
                        addOnCompleteListener(this::onCompleteListener);
            }
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        init();
        auth = FirebaseAuth.getInstance();
        Button regBtn = findViewById(R.id.registerBtn);
        regBtn.setOnClickListener(this::register);

    }

}
