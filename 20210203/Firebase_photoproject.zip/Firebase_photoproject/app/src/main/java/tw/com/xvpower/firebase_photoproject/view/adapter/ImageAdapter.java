package tw.com.xvpower.firebase_photoproject.view.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.firebase_photoproject.R;
import tw.com.xvpower.firebase_photoproject.beans.MyImageInfo;

public class ImageAdapter extends  RecyclerView.Adapter<ImageAdapter.MyViewHolder>{
    private FirebaseFirestore firebaseFirestore;
    private List<MyImageInfo> dataList = new ArrayList<>();

    public ImageAdapter(String  userid){
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseFirestore.collection("Users").
                document(userid).
                collection("images").
                addSnapshotListener(this::onReadFirebaseEven);
    }

   private void onReadFirebaseEven(QuerySnapshot snapshot,
                                   FirebaseFirestoreException ex){
                if(ex != null){
                    Log.e("Howard","onReadFirebaseEven:"+ex);
                    return;
                }
       dataList.clear();
       List<DocumentSnapshot> list =  snapshot.getDocuments();
                for (DocumentSnapshot ds : list){
                   String uri =  ds.getString("image");
                   String  msg = ds.get("image_msg",String.class);
                   MyImageInfo imageInfo = new MyImageInfo(uri,msg);
                   dataList.add(imageInfo);
                }
            notifyDataSetChanged();
   }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.rc_view_layout,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        MyImageInfo info = dataList.get(position);
        holder.msgText.setText(info.getImageMsg());
            //
            //R.drawable.download_image
        RequestOptions rq = new RequestOptions();
        //預設圖
        rq.placeholder(R.drawable.download_image);
        Glide.with(holder.imageView).
                setDefaultRequestOptions(rq).
                load(info.getImageUrl()).
                into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView msgText;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.rcMyImageView);
            msgText = itemView.findViewById(R.id.rcMsgText);
        }

    }
}
