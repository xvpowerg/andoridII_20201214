package tw.com.xvpower.firebase_photoproject.view.imageupload;

import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.function.Consumer;

public class UploadImage {
    private Uri mainImageURI;

    private String  userId;
    private ProgressBar progressBar;
    private EditText msgText;
    private Context context;
    private Consumer<Task<UploadTask.TaskSnapshot>> uploadSuccessfulListener;
    private Consumer<Task<UploadTask.TaskSnapshot>> uploadFailListener;
    private OnCompleteListener<Void> databaseCompleteListener;
    public static String IMAGE_DIR_ROOT = "upload_images";
    public UploadImage( Context context,String userId,
                        ProgressBar progressBar,
                       EditText msgText,
                        OnCompleteListener<Void> databaseCompleteListener
                      ) {
        this.userId = userId;
        this.progressBar = progressBar;
        this.msgText = msgText;
        this.context = context;
        this.databaseCompleteListener = databaseCompleteListener;
    }
        private String  gneRandomImageName(String extension){
                return System.currentTimeMillis()+"."+extension;
        }
    public void uploadImage(){
            if (!cnaUploadImage()) return;

        startProgressBar();
         StorageReference sr=
                 FirebaseStorage.getInstance().getReference();
        sr.child(IMAGE_DIR_ROOT).child(userId).
                child(gneRandomImageName("jpg")).
                putFile(mainImageURI).
                addOnCompleteListener(task->{
                    if (task.isSuccessful()){
                        downloadImageUrl(task);
                        if (uploadSuccessfulListener!=null)
                        uploadSuccessfulListener.accept(task);
                    }else{
                        if (uploadFailListener!=null)
                        uploadFailListener.accept(task);
                    }


                });
    }


    private void downloadImageUrl(Task<UploadTask.TaskSnapshot> task){
        Task<Uri> result = task.getResult().getMetadata().
                getReference().getDownloadUrl();
        result.addOnSuccessListener(uri -> {
            ImageDatabase.toDatabase(userId,getMsgText(),
                    uri.toString(),
                    databaseCompleteListener);
            stopProgressBar();
        });

    }
    public void setMainImageUri(Uri imageUri){
            this.mainImageURI = imageUri;
    }
    private void startProgressBar(){
        progressBar.setVisibility(View.VISIBLE);
    }
    private void stopProgressBar(){
        progressBar.setVisibility(View.GONE);
    }
    public String getMsgText(){
        return msgText.getText().toString();
    }

    public boolean cnaUploadImage(){
            return mainImageURI!= null;
    }

    public void setUploadSuccessfulListener(Consumer<Task<UploadTask.TaskSnapshot>> uploadSuccessfulListener) {
        this.uploadSuccessfulListener = uploadSuccessfulListener;
    }

    public void setUploadFailListener(Consumer<Task<UploadTask.TaskSnapshot>> uploadFailListener) {
        this.uploadFailListener = uploadFailListener;
    }


}
