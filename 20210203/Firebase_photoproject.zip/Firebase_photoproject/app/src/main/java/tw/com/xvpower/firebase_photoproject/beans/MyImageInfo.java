package tw.com.xvpower.firebase_photoproject.beans;

import java.util.Objects;

public class MyImageInfo {
    private String imageUrl;
    private String imageMsg;

    public MyImageInfo(String imageUrl, String imageMsg) {
        this.imageUrl = imageUrl;
        this.imageMsg = imageMsg;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageMsg() {
        return imageMsg;
    }

    public void setImageMsg(String imageMsg) {
        this.imageMsg = imageMsg;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MyImageInfo imageInfo = (MyImageInfo) o;
        return imageUrl.equals(imageInfo.imageUrl) &&
                imageMsg.equals(imageInfo.imageMsg);
    }

    @Override
    public int hashCode() {
        return Objects.hash(imageUrl, imageMsg);
    }
}
