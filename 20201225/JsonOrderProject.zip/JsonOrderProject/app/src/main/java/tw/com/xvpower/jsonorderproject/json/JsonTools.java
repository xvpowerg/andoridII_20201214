package tw.com.xvpower.jsonorderproject.json;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;

import tw.com.xvpower.jsonorderproject.bean.SerialNumber;

public class JsonTools {
    public static boolean  createJson(File file,String json){
        try(FileWriter out = new FileWriter(file)){
            out.write(json);
            return true;
        }catch (IOException ex){
            Log.e("Howard","createJson Exception:"+ex);
        }
        return false;
    }

    public static String readJson(File file){
        Path path = file.toPath();
        String jsonData = "";
        try{
            //如果不存在就建立一份檔案
            if (Files.notExists(path)) Files.createFile(path);
          byte[] jsonByte = Files.readAllBytes(path);
          jsonData = new String(jsonByte);
        }catch (IOException ex){
            Log.e("Howard","readJson:"+ex);
        }
        return jsonData;
    }

    public synchronized static SerialNumber getSerial(File file){
        String serialJson = readJson(file);
        SerialNumber serialNumber = null;
        //如果序號的Json是空的 表示檔案不存在
         //手動建立一組 SerialNumber 物件
          //如果檔案存在 把Json 反序列化 為物件
         if(serialJson.isEmpty()){
             serialNumber = new SerialNumber();
         }else{
             TypeToken<SerialNumber> typeToken =
                     new  TypeToken<SerialNumber>(){};
             serialNumber = jsonToObj(serialJson,typeToken);
         }
        serialNumber.accumulate();
         //已經改過的json寫回資料內
        serialJson = objToJson(serialNumber);
        createJson(file,serialJson);
         return serialNumber;

    }


    public static <T> String objToJson(T obj){
    Type parserType = new TypeToken<T>(){}.getType();
    Gson gson = new GsonBuilder().create();
    String json = gson.toJson(obj,parserType);
    return json;
}


public static <T> T jsonToObj(String json ,
                              TypeToken<T> token){
        Gson gson = new GsonBuilder().create();
        Type type = token.getType();
        T obj = gson.fromJson(json,type);
        return obj;
}

}
