package tw.com.xvpower.jsonorderproject.bean;

import tw.com.xvpower.jsonorderproject.dao.OrderDao;
import tw.com.xvpower.jsonorderproject.json.OrderJsonData;

public class OrderDaoFactory {
    enum OrderDaoFactoryType{
        JSON,
        SQLITE
    }
    private OrderDaoFactoryType odft ;
    public static  OrderDaoFactory orderDaoFactory;

    public static OrderDaoFactory createOrderDaoFactory(
            OrderDaoFactoryType orderDaoFactoryType){
        if (orderDaoFactory == null)
            orderDaoFactory = new OrderDaoFactory(orderDaoFactoryType);
        return orderDaoFactory;
    }


    private OrderDaoFactory(OrderDaoFactoryType orderDaoFactoryType){
        odft = orderDaoFactoryType;
    }

    public  OrderDao getOrderDao(){

            switch (odft){
                case JSON:
                    return new OrderJsonData(null,"","");
                case  SQLITE:
                    return  null;
            }
            return  null;
    }
}
