package tw.com.xvpower.jsonorderproject.dao;

import java.util.List;

import tw.com.xvpower.jsonorderproject.bean.Order;

public interface OrderDao {
    boolean createOrder(Order order);
    List<Order> queryOrder();
    Order queryOrderById(int id);
}
