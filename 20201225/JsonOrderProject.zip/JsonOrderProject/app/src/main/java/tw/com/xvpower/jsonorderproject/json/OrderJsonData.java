package tw.com.xvpower.jsonorderproject.json;

import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.jsonorderproject.bean.Order;
import tw.com.xvpower.jsonorderproject.bean.SerialNumber;
import tw.com.xvpower.jsonorderproject.dao.OrderDao;

public class OrderJsonData implements OrderDao {
    private File jsonDir;
    private String jsonName;
    private String serialFileName;
    
    public OrderJsonData(File jsonDir,String jsonName,String serialFileName){
        this.jsonDir = jsonDir;
        this.jsonName  = jsonName;
        this. serialFileName  = serialFileName;
    }
    @Override
    public boolean createOrder(Order order) {
        File jsonFile = new File(jsonDir,jsonName);
        File serialFile = new File(jsonDir,serialFileName);
        List<Order>  orderList = queryOrder();
        //產生提供給ID的序號
        SerialNumber sn =  JsonTools.getSerial(serialFile);
        order.setId(sn.getId());
        orderList.add(0,order);
        String orderListJson =  JsonTools.objToJson(orderList);
        return  JsonTools.createJson(jsonFile,orderListJson);
    }

    @Override
    public List<Order> queryOrder() {
        File jsonFile = new File(jsonDir,jsonName);
        String orderListJson =  JsonTools.readJson(jsonFile);
        ArrayList<Order>  orderList = new ArrayList();
        //如果有舊的訂單 就全查出來
        if (orderListJson != null && orderListJson.length() > 1){
            TypeToken<ArrayList<Order>> typeToken =
                    new TypeToken<ArrayList<Order>>(){};
            orderList = JsonTools.jsonToObj(orderListJson,typeToken);
        }
        return orderList;
    }

    @Override
    public Order queryOrderById(int id) {
        Order tmpOrder = new Order(id,"");
        List<Order> list =  queryOrder();
        int index =  list.indexOf(tmpOrder);
        if (index != -1){
            return list.get(index);
        }
        return null;
    }
}
