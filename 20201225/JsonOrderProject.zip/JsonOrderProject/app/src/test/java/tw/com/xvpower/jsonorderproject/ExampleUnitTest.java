package tw.com.xvpower.jsonorderproject;

import com.google.gson.reflect.TypeToken;

import org.junit.Test;

import java.io.File;
import java.util.List;

import tw.com.xvpower.jsonorderproject.bean.Order;
import tw.com.xvpower.jsonorderproject.bean.OrderDetail;
import tw.com.xvpower.jsonorderproject.bean.SerialNumber;
import tw.com.xvpower.jsonorderproject.json.JsonTools;
import tw.com.xvpower.jsonorderproject.json.OrderJsonData;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    private static  final  String path = "C:\\javacode";
    private static final String jsonName = "test.json";
    private static final  String serialJsonName = "Serial.json";
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
    @Test
    public  void readJson(){
        String path = "C:\\javacode\\test.json";
        File f = new File(path);
        String json =   JsonTools.readJson(f);
        System.out.println(json);
        assertNotEquals(json,"");
    }
    @Test
    public void testObjToJson(){
        Order order = new Order(20,"王老闆");
        OrderDetail od1 = new OrderDetail();
        od1.setName("Ps6");
        od1.setPrice(56000);
        OrderDetail od2 = new OrderDetail();
        od2.setName("iPhone15");
        od2.setPrice(32000);
        order.addOrderDetail(od1);
        order.addOrderDetail(od2);
        String json = JsonTools.objToJson(order);
        System.out.println(json);
    }

    @Test
    public void testJsonToObj(){
        String json = "{\"id\":20,\"orderName\":\"王老闆\",\"orderDetailList\":[{\"name\":\"Ps6\",\"price\":56000},{\"name\":\"iPhone15\",\"price\":32000}]}";
        TypeToken<Order> typeToken = new TypeToken<Order>(){};
        Order order = JsonTools.jsonToObj(json,typeToken);
        System.out.println(order.getId());
        System.out.println(order.getOrderName());
        order.foreachDetail(System.out::println);
    }
    @Test
    public void createOrder(){
        Order order = new Order(20,"王老闆");
        OrderDetail od1 = new OrderDetail();
        od1.setName("Ps6");
        od1.setPrice(56000);
        OrderDetail od2 = new OrderDetail();
        od2.setName("iPhone15");
        od2.setPrice(32000);
        order.addOrderDetail(od1);
        order.addOrderDetail(od2);
        File jsonDir = new File(path);
        OrderJsonData ojd = new OrderJsonData(jsonDir,jsonName,serialJsonName);
        boolean pass = ojd.createOrder(order);
        assertTrue("建立訂單失敗",pass);
    }

    @Test
    public void queryOrder(){

        File jsonDir = new File(path);
        OrderJsonData ojd =
                new OrderJsonData(jsonDir,jsonName,"");
        List<Order> list = ojd.queryOrder();
        System.out.println(list);
        assertTrue(list.size() > 0);
    }
    @Test
    public void testSerial(){
        String path = "C:\\javacode";
        File jsonDir = new File(path,serialJsonName);
       SerialNumber sn =  JsonTools.getSerial(jsonDir);
       System.out.println(sn.getId());
       assertTrue("錯誤的編號",sn.getId() > 0);
    }
    @Test
    public void testQueryByID(){
        int id = 9;
        File jsonDir = new File(path);
        OrderJsonData ojd =
                new OrderJsonData(jsonDir,jsonName,"");
        Order order =   ojd.queryOrderById(id);
        assertNotNull(order);
    }
}