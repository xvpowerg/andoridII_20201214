package tw.com.xvpower.jsonorderproject;

import org.junit.Test;

import java.io.File;

import tw.com.xvpower.jsonorderproject.json.JsonTools;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
    @Test
    public  void readJson(){
        String path = "C:\\javacode\\test.json";
        File f = new File(path);
        String json =   JsonTools.readJson(f);
        System.out.println(json);
        assertNotEquals(json,"");
    }

}