package tw.com.xvpower.jsonorderproject.json;

import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class JsonTools {
    public static void createJson(File file,String json){
        try(FileWriter out = new FileWriter(file)){
            out.write(json);
        }catch (IOException ex){
            Log.e("Howard","createJson Exception:"+ex);
        }
    }

    public static String readJson(File file){
        Path path = file.toPath();
        String jsonData = "";
        try{
            //如果不存在就建立一份檔案
            if (Files.notExists(path)) Files.createFile(path);
          byte[] jsonByte = Files.readAllBytes(path);
          jsonData = new String(jsonByte);
        }catch (IOException ex){
            Log.e("Howard","readJson:"+ex);
        }
        return jsonData;
    }

}
