package tw.com.xvpower.jsonorderproject.view;

import android.content.Context;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import tw.com.xvpower.jsonorderproject.EditOrderActivity;
import tw.com.xvpower.jsonorderproject.R;
import tw.com.xvpower.jsonorderproject.bean.Order;
import tw.com.xvpower.jsonorderproject.bean.OrderDetail;

public class AddOrderEdit {
    private class OrderDetailViewHolder{
        public OrderDetailViewHolder(EditText nameText, EditText priceText) {
            this.nameText = nameText;
            this.priceText = priceText;
        }

         EditText nameText;
         EditText priceText;
    }


    private LinearLayout productGroup;
    private Context context;
    private EditText orderNameEdit;
    private int count=0;
    private List<OrderDetailViewHolder> orderDetailEdits
            = new ArrayList<>();
    public AddOrderEdit(EditOrderActivity activity){
        productGroup =  activity.findViewById(R.id.productGroup);
        orderNameEdit = activity.findViewById(R.id.orderNameId);
        context = activity;
    }
    public void add(){
        ++count;
        TextView title = new TextView(context);
        title.setText(context.getString(R.string.order_item_info)+ count);
        title.setGravity(Gravity.CENTER);
        title.setTextSize(50);
        EditText nameText = new EditText(context);
        nameText.setHint(R.string.input_name);
        EditText priceText = new EditText(context);
        priceText.setHint(R.string.input_price);
        priceText.setInputType(InputType.TYPE_CLASS_NUMBER);
        productGroup.addView(title);
        productGroup.addView(nameText);
        productGroup.addView(priceText);
        //OrderDetailViewHolder 用來存放 動態建立的EditText
        OrderDetailViewHolder viewHolder =
                new OrderDetailViewHolder(nameText,priceText);
        orderDetailEdits.add(viewHolder);
    }
     Order  exportOrderDetail(){
       String orderName =
               orderNameEdit.getText().toString();
       Order order = new Order(0,orderName);
        for (OrderDetailViewHolder odv : orderDetailEdits){
            String nameStr =
                    odv.nameText.getText().toString();
            String priceStr =
                    odv.priceText.getText().toString();
            OrderDetail orderDetail = new OrderDetail(nameStr,priceStr);
            order.addOrderDetail(orderDetail);
        }
return order;
//        [
//        {"訂單ID",
//                "訂單名稱",
//                "訂單詳情:":[
//            {"品名","金額"}
//            {"品名","金額"}]
//        },
//        {"訂單ID",
//                "訂單名稱",
//                "訂單詳情:":[
//            {"品名","金額"}
//            {"品名","金額"}]
//        }
//
//                ]

    }

    public void save(){
            Order order = exportOrderDetail();

        String name = order.getOrderName();
        Log.d("Howard","Name:"+name);
        Log.d("Howard","ID:"+order.getId());

        order.foreachDetail(de->{
            Log.d("Howard","Detail:"+de);
        });

    }

}
