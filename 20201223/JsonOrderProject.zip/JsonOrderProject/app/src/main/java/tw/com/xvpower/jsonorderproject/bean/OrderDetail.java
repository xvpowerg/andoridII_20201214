package tw.com.xvpower.jsonorderproject.bean;

public class OrderDetail {
    private String name;
    private int price;
    private static int toInt(String value){
        int result = 0;
        try{
                result = Integer.parseInt(value);
        }catch (Exception ex){ }
        return result;
    }
    public OrderDetail() { }
    public OrderDetail(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public OrderDetail(String name, String price) {
            this(name,toInt(price));
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "OrderDetail{" +
                "name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
