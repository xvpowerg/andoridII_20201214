package tw.com.xvpower.jsonorderproject.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Order {
    private int id;
    private String orderName;
    private List<OrderDetail> orderDetailList = new ArrayList<>();
    public Order() {
    }

    public Order(int id, String title) {
        this.id = id;
        this.orderName = title;
    }

    public int getId() {
        return id;
    }

    public String getOrderName() {
        return orderName;
    }

    public List<OrderDetail> getOrderDetailList() {
        return orderDetailList;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public void setOrderDetailList(List<OrderDetail> orderDetailList) {
        this.orderDetailList = orderDetailList;
    }


    public void addOrderDetail(OrderDetail orderDetail){
        this.orderDetailList.add(orderDetail);
    }

    public void foreachDetail(Consumer<OrderDetail> consumer){
            for (OrderDetail od :  orderDetailList){
                 consumer.accept(od);
            }
    }

}
