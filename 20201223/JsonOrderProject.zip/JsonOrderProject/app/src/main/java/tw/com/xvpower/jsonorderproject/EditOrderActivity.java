package tw.com.xvpower.jsonorderproject;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import tw.com.xvpower.jsonorderproject.view.AddOrderEdit;

public class EditOrderActivity  extends AppCompatActivity {
    private AddOrderEdit addOrderEdit;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editlayout_layout);
        FloatingActionButton fb =
                findViewById(R.id.editFBtn);
        addOrderEdit = new AddOrderEdit(this);
        fb.setOnClickListener(v->{
            addOrderEdit.add();
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.save_menu_id:
                addOrderEdit.save();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}
