package tw.com.xvpower.sqliteproject.adapter;

import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.function.Consumer;

import tw.com.xvpower.sqliteproject.R;
import tw.com.xvpower.sqliteproject.bean.Student;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder>  {
    private List<Student> stList;
    private Consumer<Student> longClick;
    public StudentAdapter(List<Student> stList,
                          Consumer<Student> longClick){
        this.stList = stList;
        this.longClick = longClick;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(parent.getContext()).inflate(R.layout.student_rcview_layout,
                parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Student st = stList.get(position);
        holder.resetViewHolder(st);
        //取得Student
        holder.itemView.setOnLongClickListener(v->{
            longClick.accept(st);
            //false 如果有其他事件也會接收
            //true 只有OnLongClickListener事件才會接收
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    public void updateStudent(Student st){
        stList.set(stList.indexOf(st),st);
        notifyDataSetChanged();
    }

    public void addStudent(Student st){
            stList.add(st);
    }

    public void deleteStudent(Student st){
            stList.remove(st);
            notifyDataSetChanged();
    }

    class MyViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {
        TextView idText;
        TextView nameText;
        TextView scoreText;
        private MyViewHolder(@NonNull View itemView) {
            super(itemView);
            idText = itemView.findViewById(R.id.idText);
            nameText = itemView.findViewById(R.id.nameText);
            scoreText = itemView.findViewById(R.id.scoreText);

            itemView.setOnCreateContextMenuListener(this);
        }

        private void resetViewHolder(Student st){
            idText.setText(st.getId()+"");
            nameText.setText(st.getName());
            scoreText.setText(st.getScore()+"");
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v,
                                        ContextMenu.ContextMenuInfo menuInfo) {
            MenuInflater menuInflater = new MenuInflater(v.getContext());
            menuInflater.inflate(R.menu.content_menu,menu);

        }
    }
}
