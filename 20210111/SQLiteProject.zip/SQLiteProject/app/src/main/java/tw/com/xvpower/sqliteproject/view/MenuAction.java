package tw.com.xvpower.sqliteproject.view;

import android.content.Context;

import java.util.function.Consumer;

import tw.com.xvpower.sqliteproject.bean.Student;

public class MenuAction {
    private Context context;
    private Student currentStudent = null;

    public MenuAction(Context context){
        this.context = context;
    }

    public void setCurrentStudent(Student st){
            currentStudent = st;
    }

    private Student getCurrentStudent() {
        return currentStudent;
    }

    public void viewStudent(Consumer<Student> viewEvent){
        viewEvent.accept(getCurrentStudent());
    }

    public void updateStudent(Consumer<Student> updateEvent){
        updateEvent.accept(getCurrentStudent());

    }

    public void deleteStudent(Consumer<Student> deleteEvent){
        deleteEvent.accept(getCurrentStudent());

    }

}
