package tw.com.xvpower.sqliteproject;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class Test2 {
    //開始
    @BeforeClass
    public static  void test1(){
        System.out.println("Howard BeforeClass");
    }
    //結束
    @AfterClass
    public static void test2(){
        System.out.println("Howard AfterClass");
    }
    //每次test開始運行一次
    @Before
    public void test3(){
        System.out.println("Howard Before");
    }
    //每次test結束運行一次
    @After
    public void test4(){
        System.out.println("Howard After");
    }
    @Test
    public void myTest1(){
        System.out.println("Howard myTest1");
    }
    @Test
    public void myTest2(){
        System.out.println("Howard myTest2");
    }
}
