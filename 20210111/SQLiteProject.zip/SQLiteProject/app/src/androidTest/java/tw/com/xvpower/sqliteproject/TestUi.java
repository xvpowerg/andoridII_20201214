package tw.com.xvpower.sqliteproject;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.hamcrest.Matcher;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;


import java.util.Random;

import tw.com.xvpower.sqliteproject.matcher.RcViewMatcher;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.longClick;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.contrib.RecyclerViewActions.actionOnItem;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.hasSibling;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.not;
import static tw.com.xvpower.sqliteproject.matcher.RcViewMatcher.hashItem;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(AndroidJUnit4.class)
public class TestUi {
    static String testName ,testScore,upTestName,upTestScore;
    static  Matcher m1,m2;
    @BeforeClass
    public static void init(){
        Random random = new Random();
        testName = "TestV1"+random.nextInt(500000);
        testScore = random.nextInt(500000)+".0";
        upTestName ="UpTestV2"+random.nextInt(500000);
        upTestScore = random.nextInt(500000)+".0";
                     //hasSibling 旁邊
         m1 = allOf(withText(testName),hasSibling(withText(testScore)));
         m2 = allOf(withText(upTestName),hasSibling(withText(upTestScore)));

    }
    //設定要測試的Activity
    @Rule
    public ActivityScenarioRule<MainActivity> activityRule =
            new ActivityScenarioRule<MainActivity>(MainActivity.class);
    @Test
public void aTestInsert(){
        String name = testName;
        String score = testScore;


    onView(withId(R.id.fbEdit)).perform(click());
    onView(withId(R.id.nameEdit)).perform(typeText(name));
    onView(withId(R.id.scoreEdit)).perform(typeText(score));
    onView(withText("確定")).perform(click());

    //withText 只針對出現在畫面上的文字
    //onView(withText(name)).check(matches(withText(name)));
        //RcView一定要加 hasDescendant
        onView(withId(R.id.rcView)).check(
                matches(hashItem(hasDescendant(m1)) ));
}
@Test
    public void bTestUpdate(){
            String name = testName;
            String score = testScore;
            String upName =upTestName;
            String upScore =upTestScore;


            onView(withId(R.id.rcView)).
                    perform(actionOnItem(hasDescendant(m1),longClick()));
            onView(withText("更新")).perform(click());

            onView(withId(R.id.nameEdit)).check(matches(withText(name)));
            onView(withId(R.id.scoreEdit)).check(matches(withText(score)));

            onView(withId(R.id.nameEdit)).perform(clearText());
            onView(withId(R.id.scoreEdit)).perform(clearText());
            onView(withId(R.id.nameEdit)).perform(typeText(upName));
            onView(withId(R.id.scoreEdit)).perform(typeText(upScore));
            // android.R.id.button1 for positive,
            // android.R.id.button2 for negative,
            // and android.R.id.button3 for neutral.
            //R.id.button1 按下Alert確定的按鈕
            onView(withId(android.R.id.button1)).perform(click());
            onView(withId(R.id.rcView)).
                    check(matches(hashItem(hasDescendant(m2))));


    }

@Test
    public void cTestDelete(){
        onView(withId(R.id.rcView)).
                perform(actionOnItem(hasDescendant(m2),longClick()));
        onView(withText("刪除")).perform(click());
        onView(withId(R.id.rcView)).
                check(matches(not(hashItem(hasDescendant(m2)))) );
    }
}
