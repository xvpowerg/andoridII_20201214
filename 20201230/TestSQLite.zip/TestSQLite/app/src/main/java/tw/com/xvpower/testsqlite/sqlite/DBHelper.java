package tw.com.xvpower.testsqlite.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DBHelper  extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "myApp.db";
    public static final int DATABASE_VERSION= 2;
    private static final String CREATE_TABLE_SQL="CREATE TABLE " +
            "student(_id INTEGER PRIMARY KEY," +
            " name TEXT)";

    public DBHelper(@Nullable Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    //只會呼叫一次
    //當資料庫建立時
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("Howard","onCreate:"+CREATE_TABLE_SQL);
        db.execSQL(CREATE_TABLE_SQL);
    }

    public void insertData(String name){
        Log.d("Howard","insertData:"+name);
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name",name);
        db.insert("student",null,cv);
    }

    public void queryAllData(){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor
                =  db.rawQuery("SELECT * FROM student",null);
        while(cursor.moveToNext()){
        Log.d("Howard","id:"+cursor.getInt(0)+
                " Name:"+cursor.getString(1));
        }

    }

    public void updateData(int id){
     SQLiteDatabase db = getWritableDatabase();
    ContentValues cv = new ContentValues();
    cv.put("name","Bom");
     db.update("student",cv,"_id=?",new String[]{id+""});
    }

    public void deleteData(int id){
        SQLiteDatabase db = getWritableDatabase();
        db.delete("student","_id=?",new String[]{id+""});
    }

    //onUpgrade 當version改變時
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        Log.d("Howard","oldVersion:"+oldVersion+" newVersion:"+newVersion);

    }
}
