package tw.com.xvpower.testsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import tw.com.xvpower.testsqlite.sqlite.DBHelper;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper db = new DBHelper(this);
       // db.insertData("Iris");
        db.queryAllData();

       // db.updateData(1);
       // db.deleteData(1);
        //db.queryAllData();


    }
}