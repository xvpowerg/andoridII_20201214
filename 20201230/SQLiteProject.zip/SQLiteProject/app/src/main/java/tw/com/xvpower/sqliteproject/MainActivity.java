package tw.com.xvpower.sqliteproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         FloatingActionButton fb =  findViewById(R.id.fbEdit);
        View editView = LayoutInflater.from(this).inflate(R.layout.dialog_layout,null);
         EditText nameEdit =  editView.findViewById(R.id.nameEdit);
         EditText scoreEdit = editView.findViewById(R.id.scoreEdit);

        fb.setOnClickListener(v->{
            new AlertDialog.Builder(this).setTitle("學生資料").setView(editView).
                    setPositiveButton("確定",(d,w)->{
                        String name = nameEdit.getText().toString();
                        String score =  scoreEdit.getText().toString();
                        Log.d("Howard",name+":"+score);
                    }).
                    setNegativeButton("取消",null).
                    setCancelable(false).show();
        });

    }
}