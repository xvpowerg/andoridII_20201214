package tw.com.xvpower.testrcview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RcAdapter  extends  RecyclerView.Adapter<RcAdapter.MyViewHolader> {
    private List<String> list;
        public RcAdapter(List<String> list){
            this.list = list;
        }
    //建立ViewHolder
    @NonNull
    @Override
    public MyViewHolader onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(parent.getContext()).inflate(R.layout.list_layout,parent,false);
        MyViewHolader viewHolader = new MyViewHolader(view);
       return viewHolader;
    }

    //將ViewHolader 的元件設定數值
    @Override
    public void onBindViewHolder(@NonNull MyViewHolader holder, int position) {
        String v = list.get(position);
        holder.t1.setText(v);
        holder.t2.setText(v);
        holder.t3.setText(v);
        holder.t4.setText(v);
        holder.t5.setText(v);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolader extends  RecyclerView.ViewHolder{
        private TextView t1;
        private TextView t2;
        private TextView t3;
        private TextView t4;
        private TextView t5;
      public MyViewHolader(@NonNull View itemView) {
          super(itemView);
          t1 = itemView.findViewById(R.id.textView1);
          t2 = itemView.findViewById(R.id.textView2);
          t3 = itemView.findViewById(R.id.textView3);
          t4 = itemView.findViewById(R.id.textView4);
          t5 = itemView.findViewById(R.id.textView5);

      }
  }


}
