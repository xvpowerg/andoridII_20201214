package tw.com.xvpower.testrcview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView rcv =  findViewById(R.id.rcView);
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i<=50000;i++){
            list.add("V:"+i);
        }
        //RecyclerView 需要LayoutManager
        //rcv.setLayoutManager(new LinearLayoutManager(this));
        rcv.setLayoutManager(new GridLayoutManager(this,5));
        RcAdapter rcAdapter = new RcAdapter(list);
        rcv.setAdapter(rcAdapter);
    }
}