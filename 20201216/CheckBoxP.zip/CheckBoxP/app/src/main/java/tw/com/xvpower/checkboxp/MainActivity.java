package tw.com.xvpower.checkboxp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import java.lang.reflect.Field;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MainActivity extends AppCompatActivity {
     private int checkedCount = 0;

     private int[] checkBoxsID = {
             R.id.item0,
             R.id.item1,
             R.id.item2,
             R.id.item3
     };

     private CheckBox[] checkBoxs = new CheckBox[checkBoxsID.length];
    private CheckBox allCheckBox;
    private  SharedPreferences sp;
    private View.OnClickListener itemBoxClickListener =(ckd)->{
            CheckBox box = (CheckBox)ckd;
        if (box.isChecked()){
            checkedCount++;
        }else{
            checkedCount--;
        }
        //如果全都選取了 那就 allbox setChecked 設為true
        if (checkedCount == checkBoxsID.length){
            allCheckBox.setChecked(true);
        }else{
            allCheckBox.setChecked(false);
        }
    };
private void test1(){
    IntStream.of(checkBoxsID).
            mapToObj(id ->(CheckBox)this.findViewById(id)).
            forEach(box->
                    box.setOnClickListener(itemBoxClickListener)
            );
}
    //反射機制
    private void test2(){
            for (int i =0;i < 4;i++){
                try{
                    Field field =  R.id.class.getField("item"+i);
                    int id =   field.getInt(R.id.class);
                    checkBoxs[i] = findViewById(id);
                    checkBoxs[i].setOnClickListener(itemBoxClickListener);
                }catch (NoSuchFieldException | IllegalAccessException ex){
                        Log.e("Howard","NoSuchFieldException:"+ex);
                }
            }
    }


void display(){
     for (CheckBox box :checkBoxs){
          boolean b1 =  sp.getBoolean(String.valueOf(box.getId()),
                   false);
          box.setChecked(b1);
     }
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         sp = getSharedPreferences("check_box_sp",
                Context.MODE_PRIVATE);
        allCheckBox = findViewById(R.id.allBox);
        Button saveBtn =   findViewById(R.id.saveBtn);
            //傳統多選的第一種作法
        //test1();
        //反射機制
        test2();

        allCheckBox.setOnClickListener(v->{
            IntStream.of(checkBoxsID).
                    mapToObj(id ->(CheckBox)this.findViewById(id)).
                    forEach(box->
                            {
                                box.setChecked(allCheckBox.isChecked());
                            }
                          );
        });

        saveBtn.setOnClickListener(v -> {
             SharedPreferences.Editor edit =   sp.edit();
             for (CheckBox checkBox : checkBoxs){
                 edit.putBoolean(String.valueOf(checkBox.getId()),
                                checkBox.isChecked());
                 edit.apply();
             }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        display();
    }
}