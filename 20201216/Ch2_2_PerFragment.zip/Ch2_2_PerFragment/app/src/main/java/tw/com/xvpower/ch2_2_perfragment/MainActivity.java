package tw.com.xvpower.ch2_2_perfragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
    private HomeFragment hf;
    private MyPreferenceFragment mpf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hf = new HomeFragment();
        mpf = new MyPreferenceFragment();
    }

    @Override
    protected void onStart() {
        super.onStart();
        FragmentTransaction ft =
                getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.myContainer,hf,"").addToBackStack("");
        ft.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.set_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        FragmentTransaction ft =   getSupportFragmentManager().beginTransaction();
        switch (item.getItemId()){
            case R.id.open_set:
                ft.replace(R.id.myContainer,mpf).addToBackStack("");
                ft.commit();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}