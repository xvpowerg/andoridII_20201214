package tw.com.xvpower.test_dynamic_ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout layout =
                findViewById(R.id.containerView);
        //layout.getChildCount()
        Button button = new Button(this);
        button.setText("存檔");
        layout.addView(button);

        for (int i =1;i<=10;i++){
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText("Item:"+i);
            layout.addView(checkBox);
        }




    }
}