package tw.com.xvpower.testespresso;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button calcuBtn = findViewById(R.id.calcuBtn);
        calcuBtn.setOnClickListener(v->{
         EditText  n1Et = findViewById(R.id.number1Txt);
         EditText  n2Et = findViewById(R.id.number2Txt);
         TextView ansTxt =  findViewById(R.id.ansTxt);
         int n1 = Integer.parseInt(n1Et.getText().toString());
         int n2 =  Integer.parseInt(n2Et.getText().toString());
         int ans = n1 + n2;
         ansTxt.setText(ans+"");

        });

    }
}