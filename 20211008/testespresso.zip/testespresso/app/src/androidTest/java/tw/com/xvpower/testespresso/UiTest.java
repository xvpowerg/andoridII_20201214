package tw.com.xvpower.testespresso;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;

@RunWith(AndroidJUnit4.class)
public class UiTest {
    //跟測試平台說 我Activity是誰
    @Rule
    public ActivityScenarioRule<MainActivity> activityRule =
            new   ActivityScenarioRule(MainActivity.class);
    @Test
    public void testCalculate(){
        int n1 = 10;
        int n2 = 20;
        //onView 找
        //用甚麼條件withId 依照ID
        //perform 動作
        //typeText 輸入文字
        onView(withId(R.id.number1Txt)).
                perform(typeText(n1+""));
        onView(withId(R.id.number2Txt)).
                perform(typeText(n2+""));
        //按下按鈕
        onView(withId(R.id.calcuBtn)).perform(click());
        //產生一組符合條件 元件文字是n1+n2
        Matcher m = allOf(withText(n1+n2+""));
        //檢查ansTxt 是否為n1+n2的結果
        onView(withId(R.id.ansTxt)).check(matches(m));

    }

}
