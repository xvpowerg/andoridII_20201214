package tw.com.xvpower.sqliteproject.dao;

import java.util.List;

import tw.com.xvpower.sqliteproject.bean.Student;

public interface StudentDao {
    int insert(Student st);
    Student queryStudentById(int id);
    List<Student> queryAllStudent();
    int update(Student st);
    int delete(Student st);

}
