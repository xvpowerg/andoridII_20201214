package tw.com.xvpower.sqliteproject.view;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.function.Consumer;

import tw.com.xvpower.sqliteproject.R;
import tw.com.xvpower.sqliteproject.bean.Student;

public class StudentEditAlert {
    private Context context;
    private AlertDialog.Builder alertBuilder;
    private EditText nameEdit;
    private  EditText scoreEdit;
    private Consumer<Student> insertEvent;
    private Consumer<Student> updateEvent;
    private boolean isInsert = true;
    private Student selectStudent;

    public StudentEditAlert(Context context,Consumer<Student> insertEvent,
                                    Consumer<Student> updateEvent){
        this.context = context;
        this.insertEvent = insertEvent;
        this.updateEvent = updateEvent;
        init();
    }
    private AlertDialog.Builder newAlertDialog(){
        View editView   = LayoutInflater.from(context).inflate(R.layout.dialog_layout,null);;
        nameEdit = editView.findViewById(R.id.nameEdit);
        scoreEdit = editView.findViewById(R.id.scoreEdit);
        if (!isInsert){
            nameEdit.setText(selectStudent.getName());
            scoreEdit.setText(selectStudent.getScore()+"");
        }

        return   new AlertDialog.Builder(context).setTitle("學生資料").
                setView(editView).
                setPositiveButton("確定",(d,w)->{
                    String name = nameEdit.getText().toString();
                    String score =  scoreEdit.getText().toString();

                    Student st = new Student(0,name,
                            Float.parseFloat(score),"");

                    if (isInsert && insertEvent!= null){
                        insertEvent.accept(st);
                    }else if (!isInsert && updateEvent!= null){
                        st.setId(selectStudent.getId());
                        st.setCreateTime(selectStudent.getCreateTime());
                        updateEvent.accept(st);
                    }
                }).
                setNegativeButton("取消",null).
                setCancelable(false);
    }
    private void init(){
//         editView = LayoutInflater.from(context).inflate(R.layout.dialog_layout,null);
//         nameEdit =  editView.findViewById(R.id.nameEdit);
//         scoreEdit = editView.findViewById(R.id.scoreEdit);
    }
    public void showInsert(){
        isInsert = true;
        newAlertDialog().show();
    }

    public void showUpdate(Student updateStudent){
        selectStudent = updateStudent;
        isInsert = false;
        newAlertDialog().show();


    }
}
