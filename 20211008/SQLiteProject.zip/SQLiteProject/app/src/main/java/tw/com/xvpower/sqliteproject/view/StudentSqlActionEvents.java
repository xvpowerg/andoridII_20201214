package tw.com.xvpower.sqliteproject.view;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

import tw.com.xvpower.sqliteproject.bean.Student;
import tw.com.xvpower.sqliteproject.event.SqlActionCompletedEvent;
import tw.com.xvpower.sqliteproject.event.SqlActionCompletedEvent.SqlActionEvenType;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

public class StudentSqlActionEvents {
    private Context context;
    private DBHelper dbHelper;
    private SqlActionCompletedEvent insetCompletedEven;
    private SqlActionCompletedEvent  updateCompletedEven;
    private SqlActionCompletedEvent  deleteCompletedEven;
    public StudentSqlActionEvents(Context context,
                                  DBHelper dbHelper){
        this.context = context;
        this.dbHelper =  dbHelper;
    }

    public void setInsetCompletedEven(SqlActionCompletedEvent
                                              insetCompletedEven){
        this.insetCompletedEven = insetCompletedEven;
    }

    public void setUpdateCompletedEven(SqlActionCompletedEvent
                                               updateCompletedEven){
        this.updateCompletedEven = updateCompletedEven;
    }

    public void setDeleteCompletedEven(SqlActionCompletedEvent
                                               deleteCompletedEven){
        this.deleteCompletedEven = deleteCompletedEven;
    }




    public  void insetEvent(Student st){
        int id =  dbHelper.getStudentDao().insert(st);
        st.setId(id);
        if (insetCompletedEven!= null)
            insetCompletedEven.completed(id > 0,st,
                   SqlActionEvenType.INSERT);
    }

    public  void updateEvent(Student st){
        int count = dbHelper.getStudentDao().update(st);
        if (updateCompletedEven!= null)
            updateCompletedEven.
                    completed(count > 0,st,SqlActionEvenType.UPDATE);
    }

    public void deleteEvent(Student st){
        int count = dbHelper.getStudentDao().delete(st);
        if (deleteCompletedEven != null){
            deleteCompletedEven.completed(count > 0,st,
                    SqlActionEvenType.DELETE);
        }
    }
}
