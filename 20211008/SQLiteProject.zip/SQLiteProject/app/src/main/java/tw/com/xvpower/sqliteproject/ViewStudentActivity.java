package tw.com.xvpower.sqliteproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.sqliteproject.bean.Student;

public class ViewStudentActivity  extends AppCompatActivity {
    private TextView stIdText;
    private TextView stNameText;
    private TextView stScoreText;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.st_view_layout);
        stIdText =  findViewById(R.id.stiIdTxt);
        stNameText = findViewById(R.id.stNameTxt);
        stScoreText = findViewById(R.id.stScoreTxt);
    }

    @Override
    protected void onStart() {
        super.onStart();
       Intent dataIntent =  getIntent();
        Student st =  dataIntent.getParcelableExtra("st");
        stIdText.setText(st.getId()+"");
        stNameText.setText(st.getName()+"");
        stScoreText.setText(st.getScore()+"");
    }
}
