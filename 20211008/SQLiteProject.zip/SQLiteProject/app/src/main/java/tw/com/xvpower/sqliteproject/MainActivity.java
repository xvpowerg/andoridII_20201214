package tw.com.xvpower.sqliteproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import tw.com.xvpower.sqliteproject.adapter.StudentAdapter;
import tw.com.xvpower.sqliteproject.bean.Student;
import tw.com.xvpower.sqliteproject.event.SqlActionCompletedEvent;
import tw.com.xvpower.sqliteproject.event.SqlActionCompletedEvent.SqlActionEvenType;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;
import tw.com.xvpower.sqliteproject.view.MenuAction;
import tw.com.xvpower.sqliteproject.view.StudentSqlActionEvents;
import tw.com.xvpower.sqliteproject.view.StudentEditAlert;

public class MainActivity extends AppCompatActivity {
    private DBHelper dbHelper;
    private RecyclerView rcView;
    private StudentEditAlert studentEditAlert;
    private StudentAdapter studentAdapter ;
    private MenuAction menuAction;
    private  StudentSqlActionEvents studentSQLEvents;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         FloatingActionButton fb =  findViewById(R.id.fbEdit);
        dbHelper = new DBHelper(this);
        menuAction = new MenuAction(this);
        studentSQLEvents =
                new StudentSqlActionEvents(this,dbHelper);
        studentEditAlert = new StudentEditAlert(this,
                studentSQLEvents::insetEvent,
                studentSQLEvents::updateEvent
                );
         rcView =  findViewById(R.id.rcView);
        fb.setOnClickListener(v->studentEditAlert.showInsert());

        studentSQLEvents.setInsetCompletedEven(this::sqlActionCompleted);
        studentSQLEvents.setUpdateCompletedEven(this::sqlActionCompleted);
        studentSQLEvents.setDeleteCompletedEven(this::sqlActionCompleted);
    }


private void sqlActionCompleted(boolean pass, Student st,
                              SqlActionEvenType type){
    String msg = "";
    switch (type){
        case INSERT:
            msg=pass?"新增成功":"新增失敗";
            studentAdapter.addStudent(st);
            break;
        case UPDATE:
            msg=pass?"修改成功":"修改失敗";
            studentAdapter.updateStudent(st);
            break;
        case DELETE:
            msg=pass?"刪除成功":"刪除失敗";
            studentAdapter.deleteStudent(st);
            break;
    }
    Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
}
    @Override
    protected void onStart() {
        super.onStart();
        List<Student> list = dbHelper.getStudentDao().queryAllStudent();
        rcView.setLayoutManager(new LinearLayoutManager(this));
        //RecyclerView加線
        DividerItemDecoration itemDecoration =
                new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        rcView.addItemDecoration(itemDecoration);
        studentAdapter = new StudentAdapter(list,menuAction::setCurrentStudent);
        rcView.setAdapter(studentAdapter);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.menu_view:
                    Log.d("Howard","menu_view!");
                    menuAction.viewStudent(st->{
                        Intent toView = new Intent(this,
                                ViewStudentActivity.class);
                        toView.putExtra("st",st);
                       startActivity(toView);
                    });
                    break;
                case R.id.menu_update:
                    Log.d("Howard","menu_update!");
                    menuAction.updateStudent(st->
                            studentEditAlert.showUpdate(st));
                    break;
                case R.id.menu_delete:
                    menuAction.deleteStudent(st->
                            studentSQLEvents.deleteEvent(st));
                    break;
            }

        return super.onContextItemSelected(item);
    }
}