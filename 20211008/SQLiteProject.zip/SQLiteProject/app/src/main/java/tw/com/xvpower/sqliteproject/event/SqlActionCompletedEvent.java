package tw.com.xvpower.sqliteproject.event;

import tw.com.xvpower.sqliteproject.bean.Student;

public interface SqlActionCompletedEvent {
    enum SqlActionEvenType{
        INSERT,
        UPDATE,
        DELETE
    }
    void completed(boolean pass, Student st,SqlActionEvenType evenType);
}
