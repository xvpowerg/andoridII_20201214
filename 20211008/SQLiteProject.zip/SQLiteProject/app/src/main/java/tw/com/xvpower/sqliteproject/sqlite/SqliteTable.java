package tw.com.xvpower.sqliteproject.sqlite;

public interface SqliteTable {
    String getTableName();
    DBHelper getDBHelper();
}
