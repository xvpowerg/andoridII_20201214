package tw.com.xvpower.sqliteproject.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import tw.com.xvpower.sqliteproject.dao.StudentDao;

public class DBHelper extends SQLiteOpenHelper {
    private static final  int VERSION = 1;
    private static final String DATABASE_NAME = "student_info.db";
    public static final String STUDENT_TABLE_NAME="student";
    private static  final String CREATE_STUDENT_TABLE_TEMP="CREATE TABLE %s("+
            "_id INTEGER PRIMARY KEY,"+
            "name TEXT,"+
            "score NUMERIC,"+
            "create_time TIMESTAMP default CURRENT_TIMESTAMP"+
            ")";
    private  static String CREATE_STUDENT_TABLE;

    static{
        CREATE_STUDENT_TABLE =
                String.format(CREATE_STUDENT_TABLE_TEMP,STUDENT_TABLE_NAME);
    }
    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }


    public StudentDao getStudentDao(){
        return new StudentTable(this);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_STUDENT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
