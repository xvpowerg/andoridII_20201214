package tw.com.xvpower.testbiglistview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter  extends BaseAdapter {
    List<String> dataList ;
    public MyAdapter(List<String> dataList){
        this.dataList = dataList;
    }
    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public String getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    private static class ViewHolder{
        TextView t1;
        TextView t2;
        TextView t3;
        TextView t4;
        TextView t5;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        ViewHolder viewHolder;
        if (convertView == null){
            view =
                    LayoutInflater.from(parent.getContext()).inflate(R.layout.list_layout,
                            parent,false);
            TextView t1 = view.findViewById(R.id.textView1);
            TextView t2 = view.findViewById(R.id.textView2);
            TextView t3 = view.findViewById(R.id.textView3);
            TextView t4 = view.findViewById(R.id.textView4);
            TextView t5 =  view.findViewById(R.id.textView5);
            viewHolder = new ViewHolder();
            viewHolder.t1 = t1;
            viewHolder.t2 = t2;
            viewHolder.t3 = t3;
            viewHolder.t4 = t4;
            viewHolder.t5 = t5;
            view.setTag(viewHolder);
        }else{
            view = convertView;
            viewHolder = (ViewHolder)view.getTag();
        }

        String value =   getItem(position);
        viewHolder.t1.setText(value);
        viewHolder.t2.setText(value);
        viewHolder.t3.setText(value);
        viewHolder.t4.setText(value);
        viewHolder.t5.setText(value);
        return view;
    }
}
