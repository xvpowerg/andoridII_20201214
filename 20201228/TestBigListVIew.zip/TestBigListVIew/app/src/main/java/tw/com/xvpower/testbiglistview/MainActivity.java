package tw.com.xvpower.testbiglistview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<String>arrayList = new ArrayList<>();
        for (int i =1 ; i<=500000;i++){
            arrayList.add("v:"+i);
        }
        ListView listView =
                findViewById(R.id.myListView);
        MyAdapter myAdapter = new MyAdapter(arrayList);
        listView.setAdapter(myAdapter);
    }
}