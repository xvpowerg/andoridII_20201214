package tw.com.xvpower.widgettest2;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.util.Log;
import android.widget.RemoteViews;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GitGitWidget extends AppWidgetProvider {
    private static  final  String CLICK_IMAGE_ACTION = "click_image";
    private Handler handler = new Handler();
    private static Bitmap[] bitmaps = null;
    private ScheduledExecutorService executors;
    private RemoteViews remoteViews;
    private  AppWidgetManager appWidgetManager;
    private ComponentName thisWidget;
    private static boolean runAnimation = true;
    private int index = 0;
    private static void initBitmap(Context context){
        bitmaps = new Bitmap[24];
        for(int i=0;i<bitmaps.length;i++){
            try(InputStream is =
                        context.getAssets().open(String.format("gitgit%d.png",i+1));) {
               Bitmap bitmap = BitmapFactory.decodeStream(is);
               bitmaps[i] = bitmap;
            } catch (IOException e) {
                Log.d("Howard","IOException:"+e);
            }
        }
    }

    private void updateImage(){
        remoteViews.setImageViewBitmap(R.id.imageView,bitmaps[index]);
        index = ++index % bitmaps.length;
        appWidgetManager.updateAppWidget(thisWidget,remoteViews);
    }

    private  class MyRun implements  Runnable{
        @Override
        public void run() {
            if (runAnimation)
            handler.post(()->updateImage());
        }
    }

    private void initClickImage(Context context){
        Log.d("Howard","initClickImage....");

            final Intent intentButton = new Intent(context,GitGitWidget.class);
        intentButton.setAction(CLICK_IMAGE_ACTION);
        //FLAG_UPDATE_CURRENT 果Intent有更新 此Intent也要更新
        final PendingIntent pintent = PendingIntent.getBroadcast(context,0,
                intentButton,PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setOnClickPendingIntent(R.id.imageView,pintent);
    }
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        Log.d("Howard","onUpdate");
        //載入圖片
        if (bitmaps == null)  initBitmap(context);
        //0.1秒執行圖片的執行序工具
        executors = Executors.newSingleThreadScheduledExecutor();
        //e
        remoteViews = new RemoteViews(context.getPackageName(),R.layout.widget_layout);
        thisWidget = new ComponentName(context,GitGitWidget.class);
        this.appWidgetManager = appWidgetManager;
        //初始化Image Click
       initClickImage(context);
        MyRun myRun = new MyRun();
       executors.scheduleAtFixedRate(myRun,0,100, TimeUnit.MILLISECONDS);
    }
    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        Log.d("Howard","Stop!!");
        if(intent.getAction().equals(CLICK_IMAGE_ACTION)){
            Log.d("Howard","Stop!!");
            runAnimation = !runAnimation;
        }
    }
}
