package tw.com.xvpower.sqliteproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import tw.com.xvpower.sqliteproject.bean.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

public class MainActivity extends AppCompatActivity {
    private DBHelper dbHelper;
    private RecyclerView rcView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         FloatingActionButton fb =  findViewById(R.id.fbEdit);
         View editView = LayoutInflater.from(this).inflate(R.layout.dialog_layout,null);
         EditText nameEdit =  editView.findViewById(R.id.nameEdit);
         EditText scoreEdit = editView.findViewById(R.id.scoreEdit);

         rcView =  findViewById(R.id.rcView);
         dbHelper = new DBHelper(this);

        fb.setOnClickListener(v->{
            new AlertDialog.Builder(this).setTitle("學生資料").setView(editView).
                    setPositiveButton("確定",(d,w)->{
                        String name = nameEdit.getText().toString();
                        String score =  scoreEdit.getText().toString();
                        Student st = new Student(0,name,
                                Float.parseFloat(score),"");
                       int id =  dbHelper.getStudentDao().insert(st);
                       if (id > 0)
                           Toast.makeText(this,"新增成功",Toast.LENGTH_SHORT).show();
                       else
                           Toast.makeText(this,"新增失敗",Toast.LENGTH_SHORT).show();
                        Log.d("Howard",name+":"+score);
                    }).
                    setNegativeButton("取消",null).
                    setCancelable(false).show();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        List<Student> list = dbHelper.getStudentDao().queryAllStudent();
        rcView.setLayoutManager(new LinearLayoutManager(this));
        //rcView.setAdapter();
    }
}