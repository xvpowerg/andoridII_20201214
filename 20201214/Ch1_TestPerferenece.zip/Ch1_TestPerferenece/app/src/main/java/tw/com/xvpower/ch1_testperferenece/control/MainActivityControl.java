package tw.com.xvpower.ch1_testperferenece.control;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.ch1_testperferenece.R;

public class MainActivityControl {
    private AppCompatActivity activity;
    private SharedPreferences sp;
    private EditText accountTxt,passTxt;
    private CheckBox saveCheckBox;
    private boolean canSave = false;

    public void setCanSave(boolean canSave){
        this.canSave = canSave;
    }

    public boolean isCasSave(){
        return this.canSave;
    }

    public MainActivityControl(AppCompatActivity activity){
        this.activity = activity;

    }

    public void display(){
        String account =
                sp.getString(activity.getString(R.string.pref_account_key),"");
        String pass =
                sp.getString(activity.getString(R.string.pref_password_key),"");
        accountTxt.setText(account);
        passTxt.setText(pass);
        saveCheckBox.setChecked(canSave);
    }


    public void clear(){
        String saveAccount = "";
        String savePass = "";
        saveToPreferences(saveAccount,savePass);

    }
    public void save(){
        String  saveAccount = accountTxt.getText().toString();
        String savePass  = passTxt.getText().toString();
        saveToPreferences(saveAccount,savePass);
    }

    private void saveToPreferences(String saveAccount, String savePass){
        SharedPreferences.Editor edit = sp.edit();
        edit.putString(activity.getString(R.string.pref_account_key),saveAccount);
        edit.putString(activity.getString(R.string.pref_password_key),savePass);
        edit.putBoolean(activity.getString(R.string.pref_save_box_key),canSave);
        edit.commit();
    }

    public void init(){
       sp = activity.getSharedPreferences(activity.
                       getString(R.string.pref_file_name),
                Context.MODE_PRIVATE);
        accountTxt = activity.findViewById(R.id.accountTxt);
        passTxt = activity.findViewById(R.id.passwordTxt);
        saveCheckBox = activity.findViewById(R.id.saveBox);
        canSave =  sp.getBoolean(activity.
                getString(R.string.pref_save_box_key),false);
    }




}
