package tw.com.xvpower.ch1_testperferenece.old;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.ch1_testperferenece.R;

public class MainActivity extends AppCompatActivity {
    private EditText accountTxt,passTxt;
    private CheckBox saveCheckBox;
    private Button lgoinBtn;
    private boolean canSave = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        accountTxt = findViewById(R.id.accountTxt);
        passTxt = findViewById(R.id.passwordTxt);
        saveCheckBox = findViewById(R.id.saveBox);
        lgoinBtn = findViewById(R.id.loginBtn);
        //參數1 Preferences 的xml的檔名
        //2 模式 我們選取私有的 只能在目前App讀寫
        SharedPreferences sp = getSharedPreferences("test_login",
                                Context.MODE_PRIVATE);
        String account = sp.getString(getString(R.string.pref_account_key),"");
     String pass =    sp.getString(getString(R.string.pref_password_key),"");
       canSave =  sp.getBoolean(getString(R.string.pref_save_box_key),false);
     accountTxt.setText(account);
     passTxt.setText(pass);
     saveCheckBox.setChecked(canSave);

        lgoinBtn.setOnClickListener(v->{
            SharedPreferences.Editor edit = sp.edit();
            String savePass = "";
            String saveAccount = "";

                if (canSave){
    // 如果canSave為true 將帳號密碼存在Preference內
                    //存入Preference步驟
                    //取得一個SharedPreferences.Editor
                    //呼叫對應類型的putxxx 寫入key與value
                    //一定要記得呼叫commit()
                    savePass = passTxt.getText().toString();
                    saveAccount = accountTxt.getText().toString();
                }
                edit.putString(getString(R.string.pref_password_key),savePass);
                edit.putString(getString(R.string.pref_account_key),saveAccount);
                edit.putBoolean(getString(R.string.pref_save_box_key),canSave);
                edit.commit();
                finish();
        });

        saveCheckBox.setOnCheckedChangeListener((bv,checked)->{
            canSave = checked;

        });

    }
}