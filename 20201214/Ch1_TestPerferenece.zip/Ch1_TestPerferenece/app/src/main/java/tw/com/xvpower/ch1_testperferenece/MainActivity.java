package tw.com.xvpower.ch1_testperferenece;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import tw.com.xvpower.ch1_testperferenece.control.MainActivityControl;

public class MainActivity extends AppCompatActivity {
    private MainActivityControl control;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        control = new MainActivityControl(this);
        control.init();
        Button lgoinBtn = findViewById(R.id.loginBtn);
        CheckBox saveCheckBox = findViewById(R.id.saveBox);

        lgoinBtn.setOnClickListener(v->{
                if (control.isCasSave()){
                    control.save();
                }else{
                    control.clear();
                }
                finish();
        });

        saveCheckBox.setOnCheckedChangeListener((bv,checked)->{
            control.setCanSave(checked);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        control.display();
    }
}