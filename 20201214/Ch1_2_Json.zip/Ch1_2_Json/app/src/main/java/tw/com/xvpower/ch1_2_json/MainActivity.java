package tw.com.xvpower.ch1_2_json;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String json = String.format("{\"%s\":\"%s\"}","firstName","Ken");
        Log.d("Howard","Json:"+json);
        try {
            JSONObject obj = new JSONObject(json);

            String firstName = obj.getString("firstName");
            Log.d("Howard","firstName:"+firstName);

        } catch (JSONException e) {
            Log.e("Howard","JSONException:"+e);
        }

    }
}