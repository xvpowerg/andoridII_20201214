package tw.com.xvpower.createfile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

import tw.com.xvpower.createfile.tools.FileTools;

public class MainActivity extends AppCompatActivity {
    private String fileName = "myfile.txt";
    private EditText msgEdit;
    private TextView msgText;
    private void createFile(View view){
            try(FileOutputStream fout =
                        openFileOutput(fileName,MODE_PRIVATE);
                OutputStreamWriter osw = new OutputStreamWriter(fout)){
                String msg = msgEdit.getText().toString();
                osw.write(msg);
                Toast.makeText(this, "檔案寫入成功", Toast.LENGTH_SHORT).show();
            }catch(FileNotFoundException ex){
                Log.e("Howard","createFile FileNotFoundException:"+ex);
            }catch(IOException ex){
                Log.e("Howard","createFile IOException:"+ex);
            }
    }


    private void readFile(View view){
           Log.d("Howard","FilesDir:"+getFilesDir()) ;
        File txtFile = new File(getFilesDir(),this.fileName);
        StringBuilder sb = new StringBuilder();
        try(FileReader fr = new FileReader(txtFile)){

            char[] buffer = new char[128];
            int index = -1;
            while( (index = fr.read(buffer)) != -1){
                sb.append(buffer,0,index);
            }
            msgText.setText(sb.toString());

        }catch(FileNotFoundException ex){
                Log.e("Howard","readFile FileNotFoundException:"+ex);
        }catch (IOException ex){
            Log.e("Howard","readFile IOException:"+ex);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        msgEdit = findViewById(R.id.msgEditId);
        msgText = findViewById(R.id.msgTextId);
        Button createFileBtn =  findViewById(R.id.createFileBtn);
        Button readFileBtn =   findViewById(R.id.readFileBtn);
        Button createCacheBtn =   findViewById(R.id.createCacheBtn);
        Button readCacheBtn =   findViewById(R.id.readCacheBtn);
        Button createExBn=   findViewById(R.id.createExtrenalFIleBtn);
        Button readExteFileBtn =   findViewById(R.id.readExtrenalFIleBtn);
        createFileBtn.setOnClickListener(this::createFile);
        readFileBtn.setOnClickListener(this::readFile);

        createCacheBtn.setOnClickListener(v->{
            byte[] data = msgEdit.getText().toString().getBytes();
            boolean isPass = FileTools.createCache(this,fileName,data);
            if(isPass){
                Toast.makeText(this, "Cache成功", Toast.LENGTH_SHORT).show();
            }
        });

        readCacheBtn.setOnClickListener(v->
            FileTools.readCacheString(this,
                    fileName,
                    msgText::setText ));

        createExBn.setOnClickListener(v->{
           boolean isPass = FileTools.
                   createStringExterFile(this,fileName,msgEdit.getText().toString());
            if (isPass) Toast.makeText(this, "外部檔案建立成功",Toast.LENGTH_SHORT).show();
        });
        readExteFileBtn.setOnClickListener(v->
                FileTools.readExterFile(this,
                        fileName,msgText::setText)
        );

    }


}