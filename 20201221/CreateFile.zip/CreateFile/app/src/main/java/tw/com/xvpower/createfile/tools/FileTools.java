package tw.com.xvpower.createfile.tools;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class FileTools {

    public static boolean createCache(Context context,
                                   String fileName,
                                   byte[] data){
        File file =  new File(context.getCacheDir(),fileName);
        try(FileOutputStream fileOutputStream = new FileOutputStream(file)){
            fileOutputStream.write(data);
        }catch(IOException ex){
            Log.e("Howard","createCache IOException:ex");
            return false;
        }
        return true;
    }

    public static boolean createStringExterFile(Context context,
                                          String fileName,
                                          String data){
        /*
        type:
        Environment.DIRECTORY_MUSIC, Environment.DIRECTORY_PODCASTS, Environment.DIRECTORY_RINGTONES, Environment.DIRECTORY_ALARMS, Environment.DIRECTORY_NOTIFICATIONS, Environment.DIRECTORY_PICTURES, or Environment.DIRECTORY_MOVIES.
         */
           File fileDir =  context.getExternalFilesDir(null);
           Path path =  fileDir.toPath().resolve(fileName);
        Log.d("Howard","ExteranlDir"+fileDir);

           try{
               Files.write(path,data.getBytes());
           }catch (IOException ex){
               Log.e("Howard","IOException ExteranlDir:"+ex);
               return false;
           }
            return true;
    }

    public static void readCacheString(Context context,
                                       String fileName,
                                    Consumer<String> callBack){
        Path newPath =  context.getCacheDir().
                toPath().resolve(fileName);
        try{
            byte[] bytes = Files.readAllBytes(newPath);
            String value = new String(bytes);
            callBack.accept(value);
        }catch (IOException ex){
            Log.e("Howard","readCache Exception:"+ex);
        }
    }

    private static File getExDir(Context context){
        return context.getExternalFilesDir(null);
    }
    private static Path getExFile(Context context,String fileName){
        return getExDir(context).toPath().resolve(fileName);
    }

    public static void readExterFile(Context context,
                                     String fileName,
                                     Consumer<String> callback){
        Path path = getExFile(context,fileName);
        try{
            //多行的情況
            List<String> datas = Files.readAllLines(path);
            String strData =
                    datas.stream().
                            collect(Collectors.joining(" "));
            callback.accept(strData);
        }catch (IOException ex){
                Log.e("Howard","IOException:"+ex);
        }

    }


}
