package tw.com.xvpower.uploadimagetofirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.uploadBtn);
        StorageReference sr=
                FirebaseStorage.getInstance().getReference();
        btn.setOnClickListener(v->{
            //child 建立資料夾
           InputStream input =  getResources().openRawResource(R.raw.image2);
           UploadTask uploadTask =  sr.child("c1").child("c3").
                    child("image2.jpg").putStream(input);
            uploadTask.addOnCompleteListener(task->{
                        if  (task.isSuccessful()){
                            Toast.makeText(this,"上傳成功",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(this,"上傳失敗",Toast.LENGTH_SHORT).show();
                        }

            });

        });
    }
}