package tw.com.xvpower.firebase_photoproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loing_layout);
        Button regBtn = findViewById(R.id.reg_btn);
        Button loginBtn = findViewById(R.id.loginBtn);
        EditText accountEdit =  findViewById(R.id.accountEdit);
        EditText passEdit = findViewById(R.id.passEdit);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        regBtn.setOnClickListener(v->{
            Intent toRegister = new Intent(this,RegisterActivity.class);
            startActivity(toRegister);
            finish();
        });

        loginBtn.setOnClickListener(v->{
            String  account = accountEdit.getText().toString();
            String pass = passEdit.getText().toString();
            if (TextUtils.isEmpty(account) || TextUtils.isEmpty(pass)){
                Toast.makeText(this,"帳號或密碼不可空白", Toast.LENGTH_SHORT).show();
            }else{
                auth.signInWithEmailAndPassword(account,pass);
            }
        });


    }
}
