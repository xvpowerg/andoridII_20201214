package tw.com.xvpower.testscreenreceiver;

import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

public class ScreenService extends Service {
    private ScreenReceiver ser;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ser = new ScreenReceiver();
        Log.d("Howard","onCreate");
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(ser,intentFilter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
        unregisterReceiver(ser);
    }
}
