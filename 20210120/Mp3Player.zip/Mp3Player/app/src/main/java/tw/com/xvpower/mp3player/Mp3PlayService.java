package tw.com.xvpower.mp3player;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;

import java.io.IOException;
import java.util.Optional;
import androidx.annotation.Nullable;

public class Mp3PlayService extends Service {
    private Optional<MediaPlayer> mediaPlayerOptional = Optional.empty();
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate!!");
        if (!mediaPlayerOptional.isPresent()){
            mediaPlayerOptional = Optional.of( MediaPlayer.
                                    create(this,R.raw.test));
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("Howard","onStartCommand:"+
                intent.getStringExtra(getString(R.string.service_action)));

        String action = intent.getStringExtra(getString(R.string.service_action));
        mediaPlayerOptional.ifPresent(mply-> mediaMethod(mply,action));
        return this.START_STICKY;
    }

    private void mediaMethod(MediaPlayer mediaPlayer ,String action){
            if (action.equals(getString(R.string.play_action))){
                mediaPlayer.start();
            }else if(action.equals(getString(R.string.stop_action))){
                mediaPlayer.stop();
                try{
                    mediaPlayer.prepare();
                }catch (IOException ex){
                }

            }else if(action.equals(getString(R.string.pause_action))){
                mediaPlayer.pause();
            }
    }
}
