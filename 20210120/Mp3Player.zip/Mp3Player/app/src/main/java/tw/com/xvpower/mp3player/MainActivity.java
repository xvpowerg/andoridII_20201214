package tw.com.xvpower.mp3player;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
private Mp3Receiver receiver;

private void sendBroadcastAction(View view){
    String  action = "";
        switch (view.getId()){
            case R.id.playBtn:
                action = getString(R.string.play_action);
                break;
            case R.id.pauseBtn:
                action = getString(R.string.pause_action);
                break;
            case R.id.stopBtn:
                action = getString(R.string.stop_action);
                break;
            default:
                throw  new IllegalArgumentException("Error View");
        }
        Intent actionIntent = new Intent(action);
        sendBroadcast(actionIntent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button playBtn = findViewById(R.id.playBtn);
        Button pauseBtn = findViewById(R.id.pauseBtn);
        Button stopBtn = findViewById(R.id.stopBtn);
        playBtn.setOnClickListener(this::sendBroadcastAction);
        pauseBtn.setOnClickListener(this::sendBroadcastAction);
        stopBtn.setOnClickListener(this::sendBroadcastAction);
    }
    //註冊Broadcast
    @Override
    protected void onResume() {
        super.onResume();
        if (receiver == null){
            receiver = new Mp3Receiver();
            IntentFilter mp3Filter = new IntentFilter();
            mp3Filter.addAction(getString(R.string.play_action));
            mp3Filter.addAction(getString(R.string.pause_action));
            mp3Filter.addAction(getString(R.string.stop_action));
            registerReceiver(receiver,mp3Filter);
        }
    }

//關閉Broadcast
    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
        receiver = null;
    }


}