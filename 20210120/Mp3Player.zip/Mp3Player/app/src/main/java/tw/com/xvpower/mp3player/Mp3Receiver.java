package tw.com.xvpower.mp3player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class Mp3Receiver  extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //Log.d("Howard","intent Action:"+intent.getAction());
        Intent serviceIntent = new Intent(context,Mp3PlayService.class);
        final String PLAY_ACTION = context.getString(R.string.play_action);
        final String PAUSE_ACTION = context.getString(R.string.pause_action);
        final String STOP_ACTION = context.getString(R.string.stop_action);
        final String SERVICE_ACTION = context.getString(R.string.service_action);

      if   (intent.getAction().equals(PLAY_ACTION)){
          serviceIntent.putExtra(SERVICE_ACTION,PLAY_ACTION);
      }else if(intent.getAction().equals(PAUSE_ACTION)){
          serviceIntent.putExtra(SERVICE_ACTION,PAUSE_ACTION);
      }else if(intent.getAction().equals(STOP_ACTION)){
          serviceIntent.putExtra(SERVICE_ACTION,STOP_ACTION);
      }
        context.startService(serviceIntent);
    }
}
