package tw.com.xvpower.firebase_photoproject.view.imageupload;

import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class UploadImage {
    private Uri mainImageURI;

    private String  userId;
    private ProgressBar progressBar;
    private EditText msgText;
    private ImageView selectImage;
    private Context context;
    public static String IMAGE_DIR_ROOT = "upload_images";
    public UploadImage( Context context,String userId, ProgressBar progressBar,
                       EditText msgText, ImageView selectImage
                      ) {
        this.userId = userId;
        this.progressBar = progressBar;
        this.msgText = msgText;
        this.selectImage = selectImage;
        this.context = context;
    }
        private String  gneRandomImageName(String extension){
                return System.currentTimeMillis()+"."+extension;
        }
    public void uploadImage(){
            if (!cnaUploadImage()) return;

        startProgressBar();
         StorageReference sr=
                 FirebaseStorage.getInstance().getReference();
        sr.child(IMAGE_DIR_ROOT).child(userId).
                child(gneRandomImageName("jpg")).
                putFile(mainImageURI);
    }


    public void setMainImageUri(Uri imageUri){
            this.mainImageURI = imageUri;
    }
    private void startProgressBar(){
        progressBar.setVisibility(View.VISIBLE);
    }
    private void stopProgressBar(){
        progressBar.setVisibility(View.GONE);
    }

    public boolean cnaUploadImage(){
            return mainImageURI!= null;
    }


}
