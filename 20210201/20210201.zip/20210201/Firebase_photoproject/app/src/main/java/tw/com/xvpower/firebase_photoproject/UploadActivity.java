package tw.com.xvpower.firebase_photoproject;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

import tw.com.xvpower.firebase_photoproject.view.imageupload.UploadImage;

public class UploadActivity extends AppCompatActivity {
    private Uri mainImageURI;
    private ImageView selectImage;
    private StorageReference storageReference;
    private ProgressBar progressBar;
    private EditText msgText;
    private String  userId;
    private FirebaseFirestore firebaseDB;
    private UploadImage uploadImage;
    private void openCropImage(){

        CropImage.activity().
                setGuidelines(CropImageView.Guidelines.ON).
                start(this);
    }

    private  void openPackage(View view){
        //詢問是否提供外部讀取的權限
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE) !=
                    PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        100);
            }else{
                openCropImage();
            }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload_layout);
        ProgressBar progressBar = findViewById(R.id.progressBar);
       EditText  msgText = findViewById(R.id.msg_txt);
        Button uploadbtn = findViewById(R.id.uploadBtn);
        ImageView selectImage =
                findViewById(R.id.select_image);
        selectImage.setOnClickListener(this::openPackage);
        uploadbtn.setOnClickListener(this::uploadImage);
        storageReference = FirebaseStorage.getInstance().getReference();
        String userId = FirebaseAuth.getInstance().getUid();
        firebaseDB = FirebaseFirestore.getInstance();
        uploadImage = new UploadImage(this,
                userId,
                progressBar,
                msgText,
                selectImage);
    }

    private void uploadImage(View view){
        if(mainImageURI != null){
            Log.d("Howard","uploadImage.....");
            progressBar.setVisibility(View.VISIBLE);
             UploadTask uploadTask =   storageReference.child("upload_image").child(userId).
                    child(System.currentTimeMillis()+".jpg").
                    putFile(mainImageURI);
            uploadTask.addOnCompleteListener(task->{
                    if (task.isSuccessful()){
                       Task<Uri> result =
                               task.getResult().getMetadata().
                                       getReference().getDownloadUrl();
                        result.addOnSuccessListener(uri->{
                            String msg = msgText.getText().toString();
                            toDatabase(msg,uri.toString());
                                Log.d("Howard","upload uri:"+uri);

                        });
                        Toast.makeText(this,"上傳成功",Toast.LENGTH_SHORT).show();
                    }else{
                        String  error = task.getException().getMessage();
                            Log.e("Howard","error:"+error);
                            Toast.makeText(this,"上傳失敗",Toast.LENGTH_SHORT).show();
                    }
                progressBar.setVisibility(View.GONE);
            });

        }
    }

    private void toDatabase(String msg ,String uri){
        HashMap<String,String> data = new HashMap<>();
        data.put("image_msg",msg);
        data.put("image",uri);
        firebaseDB.collection("Users").
                document(userId).
                collection("images").
                document(System.currentTimeMillis()+"").
                set(data).addOnCompleteListener(this::toDataBaseComplete);
    }

    private void toDataBaseComplete(Task<Void> task){
            if (task.isSuccessful()){
                Toast.makeText(this,"存檔完成", Toast.LENGTH_SHORT).show();
                finish();
            }else{
                Toast.makeText(this,"存檔失敗", Toast.LENGTH_SHORT).show();
                String msg = task.getException().getMessage();
                Log.e("Howard","寫入失敗"+msg);
            }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,
                permissions, grantResults);
        if(requestCode == 100 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED){
            openCropImage();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        CropImage.ActivityResult result =
                CropImage.getActivityResult(data);
        if (resultCode == RESULT_OK){
            mainImageURI = result.getUri();
            selectImage.setImageURI(mainImageURI);
        }else if(requestCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
            Exception ex = result.getError();
            Log.e("Howard","Error:"+ex);
        }
    }
}
