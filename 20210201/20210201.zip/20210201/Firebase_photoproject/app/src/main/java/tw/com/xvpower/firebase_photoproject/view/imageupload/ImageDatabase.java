package tw.com.xvpower.firebase_photoproject.view.imageupload;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class ImageDatabase {

    static void toDatabase(String userId,String msg, String imageUri,
                           OnCompleteListener<Void> completeListener){
        HashMap<String,String> data = new HashMap<>();
        data.put("image_msg",msg);
        data.put("image",imageUri);
        FirebaseFirestore.getInstance().collection("Users").
                document(userId).
                collection("images").
                document(System.currentTimeMillis()+"").
                set(data).addOnCompleteListener(completeListener);
    }
}
