package tw.com.xvpower.sqliteproject;

import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import tw.com.xvpower.sqliteproject.bean.Student;
import tw.com.xvpower.sqliteproject.dao.StudentDao;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private static Context appContext;
    private static DBHelper dbHelper;
    @BeforeClass
    public static void init(){
        appContext =
                InstrumentationRegistry.getInstrumentation().getTargetContext();
        dbHelper = new DBHelper(appContext);
    }
    @AfterClass
    public static void destroy(){
        dbHelper = null;
        appContext = null;
    }
    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("tw.com.xvpower.sqliteproject", appContext.getPackageName());
    }
    @Test
    public void testStudentInsert(){
            Student st1 = new Student(-1,"Lindy",
                    78.6f,"");
        StudentDao studentDao =  dbHelper.getStudentDao();
        int id = studentDao.insert(st1);
        System.out.println("id:"+id);
        assertTrue("Insert Fail",id > 0);
    }
@Test
    public void testQueryStudentById(){
        int id = 1;
        Student st =
                dbHelper.getStudentDao().queryStudentById(id);
        System.out.println(st);
        assertNotNull("查詢錯誤!",st);

    }
@Test
    public void testQueryAllStudent(){
        List<Student> list =
                dbHelper.getStudentDao().queryAllStudent();
        System.out.println(list);
        assertTrue("Query fail",list.size() > 0);
    }
@Test
    public void testUpdate(){
        Student st1 = new Student(1,"Vivin",98.6f,
                    "");
       int count =  dbHelper.getStudentDao().update(st1);
       assertTrue("更新失敗",count > 0);

    }
    @Test
   public void testDelete(){
        Student st = new Student(2,"",1,"");
        int count =   dbHelper.getStudentDao().delete(st);
        assertTrue("Delete Error",count > 0);

   }
}