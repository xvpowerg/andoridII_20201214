package tw.com.xvpower.sqliteproject.view;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

import tw.com.xvpower.sqliteproject.bean.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;

public class StudentAlertSqlEvents {
    private Context context;
    private DBHelper dbHelper;
    private BiConsumer<Boolean,Student>  insetCompletedEven;
    private BiConsumer<Boolean,Student>  updateCompletedEven;
    public StudentAlertSqlEvents(Context context,
                                 DBHelper dbHelper){
        this.context = context;
        this.dbHelper =  dbHelper;
    }

    public void setInsetCompletedEven(BiConsumer<Boolean,Student>
                                              insetCompletedEven){
        this.insetCompletedEven = insetCompletedEven;
    }

    public void setUpdateCompletedEven(BiConsumer<Boolean,Student>
                                               updateCompletedEven){
        this.updateCompletedEven = updateCompletedEven;
    }
    public  void insetEvent(Student st){
        int id =  dbHelper.getStudentDao().insert(st);
        st.setId(id);
        if (insetCompletedEven!= null)  insetCompletedEven.accept(id > 0,st);
    }

    public  void updateEvent(Student st){

        if (updateCompletedEven!= null)
            updateCompletedEven.accept(true,st);
    }
}
