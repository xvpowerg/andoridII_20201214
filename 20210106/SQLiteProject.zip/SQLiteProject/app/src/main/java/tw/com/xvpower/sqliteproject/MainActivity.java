package tw.com.xvpower.sqliteproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import tw.com.xvpower.sqliteproject.adapter.StudentAdapter;
import tw.com.xvpower.sqliteproject.bean.Student;
import tw.com.xvpower.sqliteproject.sqlite.DBHelper;
import tw.com.xvpower.sqliteproject.view.MenuAction;
import tw.com.xvpower.sqliteproject.view.StudentAlertSqlEvents;
import tw.com.xvpower.sqliteproject.view.StudentEditAlert;

public class MainActivity extends AppCompatActivity {
    private DBHelper dbHelper;
    private RecyclerView rcView;
    private StudentEditAlert studentEditAlert;
    private StudentAdapter studentAdapter ;
    private MenuAction menuAction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         FloatingActionButton fb =  findViewById(R.id.fbEdit);
        dbHelper = new DBHelper(this);
        menuAction = new MenuAction(this);
        StudentAlertSqlEvents studentAlertEvents =
                new StudentAlertSqlEvents(this,dbHelper);
        studentEditAlert = new StudentEditAlert(this,
                studentAlertEvents::insetEvent,
                studentAlertEvents::updateEvent
                );
         rcView =  findViewById(R.id.rcView);
        fb.setOnClickListener(v->studentEditAlert.showInsert());
        studentAlertEvents.setInsetCompletedEven((pass,st)->{
            String msg = "新增失敗";
            if (pass){
                msg = "新增成功";
                studentAdapter.addStudent(st);
            }
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        List<Student> list = dbHelper.getStudentDao().queryAllStudent();
        rcView.setLayoutManager(new LinearLayoutManager(this));
        studentAdapter = new StudentAdapter(list,menuAction::setCurrentStudent);
        rcView.setAdapter(studentAdapter);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.menu_view:
                    Log.d("Howard","menu_view!");
                    menuAction.viewStudent();
                    break;
                case R.id.menu_update:
                    Log.d("Howard","menu_update!");
                    studentEditAlert.showUpdate(menuAction.getCurrentStudent());
                   // menuAction.updateStudent();
                    break;
                case R.id.menu_delete:
                    Log.d("Howard","menu_delete!");
                    menuAction.deleteStudent();
                    break;
            }

        return super.onContextItemSelected(item);
    }
}