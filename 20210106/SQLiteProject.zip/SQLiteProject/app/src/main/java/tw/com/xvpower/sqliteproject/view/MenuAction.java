package tw.com.xvpower.sqliteproject.view;

import android.content.Context;

import tw.com.xvpower.sqliteproject.bean.Student;

public class MenuAction {
    private Context context;
    private Student currentStudent = null;

    public MenuAction(Context context){
        this.context = context;
    }

    public void setCurrentStudent(Student st){
            currentStudent = st;
    }

    public Student getCurrentStudent() {
        return currentStudent;
    }

    public void viewStudent(){

    }

    public void updateStudent(){

    }

    public void deleteStudent(){

    }

}
